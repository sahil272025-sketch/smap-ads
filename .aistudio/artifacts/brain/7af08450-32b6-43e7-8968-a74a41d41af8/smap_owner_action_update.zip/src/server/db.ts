import fs from 'fs';
import path from 'path';
import { VERIFIED_META_ACCESS_TOKEN } from './metaTokenFallback.js';

export interface User {
  id: string;
  google_sub: string;
  name: string;
  email: string;
  email_verified: boolean;
  profile_picture: string | null;
  role: 'customer' | 'admin';
  status: 'ACTIVE' | 'SUSPENDED';
  created_at: string;
  last_login_at: string;
  phone?: string;
  password_hash?: string | null;
  wallet_balance?: number; // In INR (default 0)
  promotional_credit_granted?: boolean;
  updated_at?: string;
}

export type WalletTransactionType =
  | 'ADD_FUNDS'
  | 'CAMPAIGN_PAYMENT'
  | 'REFUND'
  | 'FAILED_PAYMENT'
  | 'AUDIT_CORRECTION'
  | 'PROMOTIONAL_CREDIT';

export type WalletTransactionStatus = 'SUCCESS' | 'FAILED' | 'PENDING';

export interface WalletTransaction {
  id: string;
  user_id: string;
  type: WalletTransactionType;
  amount: number;
  balance_before: number;
  balance_after: number;
  description: string;
  payment_id?: string | null;
  gateway_payment_id?: string | null;
  gateway_order_id?: string | null;
  campaign_id?: string | null;
  status: WalletTransactionStatus;
  created_at: string;
}

export interface Package {
  id: string;
  name: string;
  price: number; // ₹200, ₹399, ₹549, ₹749
  duration_days: number; // 5, 10, 14, 30
  platform_fee?: number;
  media_spend?: number;
  payer_entity?: string;
  platforms: string[]; // ['Facebook', 'Instagram']
  features: string[];
  active: boolean;
  is_popular?: boolean;
  created_at: string;
}

export type CampaignObjective = 'AWARENESS' | 'TRAFFIC' | 'ENGAGEMENT' | 'LEADS' | 'SALES';

export type PlacementType = 'facebook_feed' | 'instagram_feed' | 'instagram_stories' | 'instagram_reels';

export type CampaignStatus = 
  | 'DRAFT'
  | 'QUEUED'
  | 'PENDING_REVIEW'
  | 'PAYMENT_PENDING'
  | 'PAYMENT_CONFIRMED'
  | 'META_NOT_CONNECTED'
  | 'SUBMITTING'
  | 'UNDER_REVIEW'
  | 'ACTIVE'
  | 'PAUSED'
  | 'COMPLETED'
  | 'REJECTED'
  | 'FAILED';

export interface CampaignTargeting {
  country: string;
  state: string;
  city: string;
  min_age: number;
  max_age: number;
  gender: 'ALL' | 'MEN' | 'WOMEN';
  interests: string[];
  locations?: string[];
  estimated_audience_size?: string;
}

export interface Campaign {
  id: string;
  user_id: string;
  package_id: string;
  objective?: CampaignObjective;
  creative_url: string;
  creative_type: 'image' | 'video';
  business_name: string;
  primary_text: string;
  headline: string;
  description: string;
  call_to_action?: string;
  destination_type: 'website' | 'whatsapp' | 'facebook_page' | 'instagram_profile';
  destination_url: string;
  placements?: PlacementType[];
  targeting: CampaignTargeting;
  daily_budget?: number;
  duration_days?: number;
  total_budget?: number;
  start_at: string | null;
  end_at: string | null;
  status: CampaignStatus;
  queue_status?: 'QUEUED' | 'PROCESSING' | 'COMPLETED' | 'RETRYING' | 'FAILED' | null;
  retry_count?: number;
  last_retry_at?: string | null;
  next_retry_at?: string | null;
  last_synced_at?: string | null;
  meta_campaign_id: string | null;
  meta_adset_id: string | null;
  meta_creative_id: string | null;
  meta_ad_id: string | null;
  meta_account_id: string | null;
  meta_status_message: string | null;
  rejection_reason: string | null;
  error_details: string | null;
  created_at: string;
  updated_at: string;
}

export type PaymentStatus = 
  | 'PENDING'
  | 'VERIFICATION_PENDING'
  | 'PAID'
  | 'FAILED'
  | 'CANCELLED'
  | 'REFUND_PENDING'
  | 'REFUNDED';

export interface Payment {
  id: string;
  user_id: string;
  campaign_id: string;
  package_id: string;
  amount: number;
  currency: 'INR';
  payment_method: 'UPI';
  payee_upi: string;
  upi_intent_url: string;
  transaction_reference: string | null; // UTR or customer reference
  gateway_payment_id: string | null;
  gateway_order_id: string | null;
  gateway_key_id?: string | null;
  status: PaymentStatus;
  webhook_status?: 'PENDING' | 'PROCESSED' | 'FAILED' | null;
  failure_reason?: string | null;
  idempotency_key?: string | null;
  paid_at?: string | null;
  verified_at: string | null;
  verification_source: 'GATEWAY_WEBHOOK' | 'GATEWAY_API' | 'ADMIN_MANUAL_VERIFICATION' | 'WALLET_BALANCE' | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

export interface MetaPage {
  id: string;
  name: string;
  access_token?: string;
  category?: string;
  tasks?: string[];
  instagram_account_id?: string;
  instagram_username?: string;
}

export interface MetaInstagramAccount {
  id: string;
  username: string;
  name?: string;
  page_id?: string;
}

export interface MetaConnection {
  id: string;
  user_id: string;
  meta_user_id: string;
  meta_user_name: string;
  access_token: string;
  token_expires_at: string;
  token_type?: 'short_lived' | 'long_lived' | 'system';
  ad_accounts: Array<{
    id: string;
    account_id: string;
    name: string;
    currency: string;
    account_status: number;
  }>;
  selected_ad_account_id: string | null;
  pages?: MetaPage[];
  selected_page_id?: string | null;
  page_id?: string;
  page_name?: string;
  instagram_accounts?: MetaInstagramAccount[];
  selected_instagram_id?: string | null;
  instagram_id?: string;
  instagram_username?: string;
  is_server_verified?: boolean;
  created_at: string;
  updated_at: string;
}

export interface SupportTicketReply {
  id: string;
  sender: 'user' | 'admin';
  sender_name: string;
  message: string;
  created_at: string;
}

export interface SupportTicket {
  id: string;
  user_id: string;
  user_name: string;
  user_email: string;
  campaign_id: string | null;
  subject: string;
  message: string;
  attachment_url: string | null;
  status: 'OPEN' | 'IN_PROGRESS' | 'RESOLVED' | 'CLOSED';
  created_at: string;
  updated_at: string;
  replies: SupportTicketReply[];
}

export interface SystemLog {
  id: string;
  category: 'AUTH' | 'PAYMENT' | 'META_API' | 'SCHEDULER' | 'ADMIN' | 'CAMPAIGN' | 'QUEUE';
  level: 'INFO' | 'WARN' | 'ERROR';
  message: string;
  details?: Record<string, unknown>;
  created_at: string;
}

interface DatabaseSchema {
  users: User[];
  packages: Package[];
  campaigns: Campaign[];
  payments: Payment[];
  meta_connections: MetaConnection[];
  support_tickets: SupportTicket[];
  system_logs: SystemLog[];
  wallet_transactions: WalletTransaction[];
}

const DEFAULT_DATA_DIR = path.resolve(process.cwd(), 'data');
const DATA_DIR = process.env.RENDER_DISK_PATH ||
  process.env.DATA_DIR ||
  (fs.existsSync('/var/data') ? '/var/data' : DEFAULT_DATA_DIR);
const DB_FILE = path.join(DATA_DIR, 'smap_db.json');

class DatabaseService {
  private db: DatabaseSchema = {
    users: [],
    packages: [],
    campaigns: [],
    payments: [],
    meta_connections: [],
    support_tickets: [],
    system_logs: [],
    wallet_transactions: [],
  };

  constructor() {
    this.init();
  }

  private init() {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    const uploadsDir = path.join(DATA_DIR, 'uploads');
    if (!fs.existsSync(uploadsDir)) {
      fs.mkdirSync(uploadsDir, { recursive: true });
    }

    // If using an external persistent disk and DB_FILE does not exist yet, copy initial seed
    if (!fs.existsSync(DB_FILE) && DATA_DIR !== DEFAULT_DATA_DIR) {
      const defaultDbFile = path.join(DEFAULT_DATA_DIR, 'smap_db.json');
      if (fs.existsSync(defaultDbFile)) {
        try {
          fs.copyFileSync(defaultDbFile, DB_FILE);
        } catch {
          // ignore
        }
      }
    }

    if (fs.existsSync(DB_FILE)) {
      try {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        this.db = JSON.parse(raw);
        // Ensure valid users array and initialize wallet_balance
        if (Array.isArray(this.db.users)) {
          this.db.users = this.db.users.filter(u => u && u.id && u.email).map(u => ({
            ...u,
            wallet_balance: typeof u.wallet_balance === 'number' && !isNaN(u.wallet_balance) ? u.wallet_balance : 0,
          }));
        }
        // Ensure wallet_transactions array exists
        if (!Array.isArray(this.db.wallet_transactions)) {
          this.db.wallet_transactions = [];
        }
      } catch (err) {
        console.error('Failed to parse existing DB file, reinitializing', err);
        this.seedInitialData();
      }
    } else {
      this.seedInitialData();
    }

    // Ensure packages are present and match specifications
    this.ensureDefaultPackages();

    // Ensure canonical owner account exists with admin role and initial ₹0 balance
    this.ensureOwnerAccount();
  }

  public save() {
    try {
      const tempFile = `${DB_FILE}.tmp`;
      fs.writeFileSync(tempFile, JSON.stringify(this.db, null, 2), 'utf-8');
      fs.renameSync(tempFile, DB_FILE);
    } catch (err) {
      console.error('Failed to persist database file', err);
    }
  }

  private seedInitialData() {
    this.db.users = [
      {
        id: 'usr_email_1791359843971_4nleif',
        google_sub: '',
        name: 'Sahil Gupta',
        email: 'sahilguptasahilgupta652@gmail.com',
        email_verified: true,
        profile_picture: null,
        role: 'customer',
        status: 'ACTIVE',
        wallet_balance: 1,
        created_at: '2026-10-07T07:57:23.972Z',
        last_login_at: '2026-10-07T08:10:52.498Z',
      },
    ];
    this.db.payments = [
      {
        id: 'smap_fund_1791373476905_af8ur6',
        user_id: 'usr_email_1791359843971_4nleif',
        campaign_id: 'WALLET_TOPUP',
        package_id: 'wallet_topup',
        amount: 1,
        currency: 'INR',
        payment_method: 'UPI',
        payee_upi: 'sahil-stp@ybl',
        upi_intent_url: '',
        transaction_reference: '257178192361',
        gateway_payment_id: 'pay_TkzwZX48FPxEce',
        gateway_order_id: 'order_TkzwZW0pSNkSNr',
        gateway_key_id: 'rzp_live_Tky7id9ihMcNqC',
        status: 'PAID',
        webhook_status: 'PROCESSED',
        failure_reason: null,
        idempotency_key: null,
        paid_at: '2026-10-07T11:15:00.000Z',
        verified_at: '2026-10-07T11:44:36.905Z',
        verification_source: 'GATEWAY_API',
        notes: 'Verified against Razorpay LIVE captured payment (pay_TkzwZX48FPxEce)',
        created_at: '2026-10-07T11:15:00.000Z',
        updated_at: '2026-10-07T11:44:36.905Z',
      },
    ];
    this.db.wallet_transactions = [
      {
        id: 'wtx_1791373476906_szctr7',
        user_id: 'usr_email_1791359843971_4nleif',
        type: 'ADD_FUNDS',
        amount: 1,
        balance_before: 0,
        balance_after: 1,
        description: 'Added funds via Razorpay UPI (257178192361)',
        payment_id: 'smap_fund_1791373476905_af8ur6',
        gateway_payment_id: 'pay_TkzwZX48FPxEce',
        gateway_order_id: 'order_TkzwZW0pSNkSNr',
        campaign_id: null,
        status: 'SUCCESS',
        created_at: '2026-10-07T11:44:36.906Z',
      },
    ];
    this.seedDefaultPackages();
    this.log('AUTH', 'INFO', 'Production database initialized with clean Google Authentication architecture');
    this.save();
  }

  private seedDefaultPackages() {
    const now = new Date().toISOString();
    this.db.packages = [
      {
        id: 'pkg_starter_200',
        name: 'Starter Sprint',
        price: 200,
        duration_days: 5,
        platforms: ['Facebook', 'Instagram'],
        features: [
          '5 Days duration',
          'Facebook + Instagram advertising',
          'Target audience setup',
          'Campaign management',
          'Campaign status tracking',
          'UPI Instant Intent checkout',
        ],
        active: true,
        created_at: now,
      },
      {
        id: 'pkg_growth_399',
        name: 'Growth Accelerate',
        price: 399,
        duration_days: 10,
        platforms: ['Facebook', 'Instagram'],
        features: [
          '10 Days duration',
          'Facebook + Instagram advertising',
          'Target audience setup',
          'Campaign management',
          'Campaign status tracking',
          'Priority campaign monitoring',
        ],
        active: true,
        is_popular: true,
        created_at: now,
      },
      {
        id: 'pkg_pro_549',
        name: 'Business Pro',
        price: 549,
        duration_days: 14,
        platforms: ['Facebook', 'Instagram'],
        features: [
          '14 Days duration',
          'Facebook + Instagram advertising',
          'Target audience setup',
          'Campaign management',
          'Campaign status tracking',
          'Extended auction reach stability',
        ],
        active: true,
        created_at: now,
      },
      {
        id: 'pkg_scale_749',
        name: 'Enterprise Scale',
        price: 749,
        duration_days: 30,
        platforms: ['Facebook', 'Instagram'],
        features: [
          '30 Days full monthly duration',
          'Facebook + Instagram advertising',
          'Target audience setup',
          'Campaign management',
          'Campaign status tracking',
          'Long-term audience learning phase',
        ],
        active: true,
        created_at: now,
      },
    ];
  }

  private ensureDefaultPackages() {
    if (!this.db.packages || this.db.packages.length === 0) {
      this.seedDefaultPackages();
      this.save();
      return;
    }

    // Guarantee exact fixed pricing on canonical packages:
    // Starter Sprint: ₹200 (5 days)
    // Growth Accelerate: ₹399 (10 days)
    // Business Pro: ₹549 (14 days)
    // Enterprise Scale: ₹749 (30 days)
    const canonicalMap: Record<string, { name: string; price: number; duration: number; platform_fee: number; media_spend: number }> = {
      pkg_starter_200: { name: 'Starter Sprint', price: 200, duration: 5, platform_fee: 100, media_spend: 100 },
      pkg_growth_399: { name: 'Growth Accelerate', price: 399, duration: 10, platform_fee: 150, media_spend: 249 },
      pkg_pro_549: { name: 'Business Pro', price: 549, duration: 14, platform_fee: 200, media_spend: 349 },
      pkg_scale_749: { name: 'Enterprise Scale', price: 749, duration: 30, platform_fee: 250, media_spend: 499 },
    };

    let updated = false;
    for (const [id, spec] of Object.entries(canonicalMap)) {
      const existing = this.db.packages.find((p) => p.id === id);
      if (existing) {
        if (
          existing.price !== spec.price ||
          existing.duration_days !== spec.duration ||
          existing.platform_fee !== spec.platform_fee ||
          existing.media_spend !== spec.media_spend
        ) {
          existing.price = spec.price;
          existing.duration_days = spec.duration;
          existing.name = spec.name;
          existing.platform_fee = spec.platform_fee;
          existing.media_spend = spec.media_spend;
          existing.payer_entity = 'Customer pays SMAP via UPI. Meta bills SMAP Agency Ad Account directly for ad spend.';
          updated = true;
        }
      } else {
        this.db.packages.push({
          id,
          name: spec.name,
          price: spec.price,
          duration_days: spec.duration,
          platform_fee: spec.platform_fee,
          media_spend: spec.media_spend,
          payer_entity: 'Customer pays SMAP via UPI. Meta bills SMAP Agency Ad Account directly for ad spend.',
          platforms: ['Facebook', 'Instagram'],
          features: [
            `${spec.duration} Days duration`,
            'Facebook + Instagram advertising',
            `₹${spec.media_spend} Meta media budget (~₹${(spec.media_spend / spec.duration).toFixed(1)}/day)`,
            `₹${spec.platform_fee} Platform setup & monitoring fee`,
            'Automated pause when package expires',
          ],
          active: true,
          created_at: new Date().toISOString(),
        });
        updated = true;
      }
    }
    if (updated) {
      this.save();
    }
  }

  /**
   * Ensures the verified owner account (sahil272025@gmail.com) exists with admin privileges.
   * NOTE: Balance starts strictly at ₹0.00 and promotional_credit_granted is false.
   * The one-time ₹50,000 credit requires explicit authenticated owner action.
   */
  private ensureOwnerAccount() {
    const ownerEmail = 'sahil272025@gmail.com';
    let owner = this.findUserByEmail(ownerEmail);
    if (!owner) {
      owner = {
        id: 'usr_owner_sahil272025',
        google_sub: '',
        name: 'Sahil Gupta',
        email: ownerEmail,
        email_verified: true,
        profile_picture: null,
        role: 'admin',
        status: 'ACTIVE',
        wallet_balance: 0,
        promotional_credit_granted: false,
        created_at: new Date().toISOString(),
        last_login_at: new Date().toISOString(),
      };
      this.db.users.push(owner);
      this.save();
    } else {
      if (owner.role !== 'admin') {
        owner.role = 'admin';
        this.save();
      }
    }
  }

  // System Logs
  public log(category: SystemLog['category'], level: SystemLog['level'], message: string, details?: Record<string, unknown>) {
    const entry: SystemLog = {
      id: `log_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
      category,
      level,
      message,
      details,
      created_at: new Date().toISOString(),
    };
    this.db.system_logs.unshift(entry);
    // Keep last 1000 logs
    if (this.db.system_logs.length > 1000) {
      this.db.system_logs = this.db.system_logs.slice(0, 1000);
    }
    this.save();
    return entry;
  }

  private reloadFromDisk() {
    try {
      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        const data = JSON.parse(raw);
        if (Array.isArray(data.users)) {
          this.db.users = data.users.filter((u: User) => u && u.id && u.email);
        }
      }
    } catch {
      // ignore
    }
  }

  // Users
  public getUsers() { return this.db.users; }
  public findUserById(id: string) {
    let u = this.db.users.find(user => user.id === id);
    if (!u) {
      this.reloadFromDisk();
      u = this.db.users.find(user => user.id === id);
    }
    return u;
  }
  public findUserByGoogleSub(googleSub: string) {
    let u = this.db.users.find(user => user.google_sub === googleSub);
    if (!u) {
      this.reloadFromDisk();
      u = this.db.users.find(user => user.google_sub === googleSub);
    }
    return u;
  }
  public findUserByEmail(email: string) {
    let u = this.db.users.find(user => user.email.toLowerCase() === email.toLowerCase());
    if (!u) {
      this.reloadFromDisk();
      u = this.db.users.find(user => user.email.toLowerCase() === email.toLowerCase());
    }
    return u;
  }
  public findUserByPhone(phone: string) {
    const cleanDigits = phone.replace(/\D/g, '');
    if (!cleanDigits || cleanDigits.length < 10) return undefined;
    let u = this.db.users.find(user => {
      if (!user.phone) return false;
      const userDigits = user.phone.replace(/\D/g, '');
      return userDigits.endsWith(cleanDigits.slice(-10)) || cleanDigits.endsWith(userDigits.slice(-10));
    });
    if (!u) {
      this.reloadFromDisk();
      u = this.db.users.find(user => {
        if (!user.phone) return false;
        const userDigits = user.phone.replace(/\D/g, '');
        return userDigits.endsWith(cleanDigits.slice(-10)) || cleanDigits.endsWith(userDigits.slice(-10));
      });
    }
    return u;
  }
  public createUser(user: User) {
    this.db.users.push(user);
    this.save();
    return user;
  }
  public updateUser(id: string, updates: Partial<User>) {
    const idx = this.db.users.findIndex(u => u.id === id);
    if (idx !== -1) {
      this.db.users[idx] = { ...this.db.users[idx], ...updates, updated_at: new Date().toISOString() };
      this.save();
      return this.db.users[idx];
    }
    return null;
  }

  // Packages
  public getPackages(onlyActive = true) {
    return onlyActive ? this.db.packages.filter(p => p.active) : this.db.packages;
  }
  public findPackageById(id: string): Package | undefined {
    if (!id) return undefined;
    const direct = this.db.packages.find(p => p.id === id);
    if (direct) return direct;

    const norm = id.toLowerCase().replace(/[-_]/g, '');
    if (norm.includes('starter') || norm.includes('sprint')) {
      return this.db.packages.find(p => p.id === 'pkg_starter_200');
    }
    if (norm.includes('growth') || norm.includes('accelerate') || norm.includes('booster')) {
      return this.db.packages.find(p => p.id === 'pkg_growth_399');
    }
    if (norm.includes('business') || norm.includes('pro')) {
      return this.db.packages.find(p => p.id === 'pkg_pro_549');
    }
    if (norm.includes('scale') || norm.includes('enterprise')) {
      return this.db.packages.find(p => p.id === 'pkg_scale_749');
    }
    return undefined;
  }
  public createPackage(pkg: Package) {
    this.db.packages.push(pkg);
    this.save();
    return pkg;
  }
  public updatePackage(id: string, updates: Partial<Package>) {
    const idx = this.db.packages.findIndex(p => p.id === id);
    if (idx !== -1) {
      this.db.packages[idx] = { ...this.db.packages[idx], ...updates };
      this.save();
      return this.db.packages[idx];
    }
    return null;
  }

  // Campaigns
  public getCampaigns(userId?: string) {
    if (userId) {
      return this.db.campaigns.filter(c => c.user_id === userId);
    }
    return this.db.campaigns;
  }
  public findCampaignById(id: string) { return this.db.campaigns.find(c => c.id === id); }
  public createCampaign(campaign: Campaign) {
    this.db.campaigns.unshift(campaign);
    this.save();
    return campaign;
  }
  public updateCampaign(id: string, updates: Partial<Campaign>) {
    const idx = this.db.campaigns.findIndex(c => c.id === id);
    if (idx !== -1) {
      this.db.campaigns[idx] = { ...this.db.campaigns[idx], ...updates, updated_at: new Date().toISOString() };
      this.save();
      return this.db.campaigns[idx];
    }
    return null;
  }

  // Payments
  public getPayments(userId?: string) {
    if (userId) {
      return this.db.payments.filter(p => p.user_id === userId);
    }
    return this.db.payments;
  }
  public findPaymentById(id: string) { return this.db.payments.find(p => p.id === id); }
  public findPaymentsByUserId(userId: string): Payment[] { return this.getPayments(userId); }
  public findPaymentByCampaignId(campaignId: string) { return this.db.payments.find(p => p.campaign_id === campaignId); }
  public findPaymentByGatewayOrderId(orderId: string) { return this.db.payments.find(p => p.gateway_order_id === orderId); }
  public findPaymentByGatewayPaymentId(paymentId: string) { return this.db.payments.find(p => p.gateway_payment_id === paymentId); }
  public findPaymentByTransactionReference(ref: string) {
    if (!ref) return undefined;
    const clean = ref.trim().toLowerCase();
    return this.db.payments.find(p => p.transaction_reference && p.transaction_reference.trim().toLowerCase() === clean);
  }
  public createPayment(payment: Payment) {
    this.db.payments.unshift(payment);
    this.save();
    return payment;
  }
  public updatePayment(id: string, updates: Partial<Payment>) {
    const idx = this.db.payments.findIndex(p => p.id === id);
    if (idx !== -1) {
      this.db.payments[idx] = { ...this.db.payments[idx], ...updates, updated_at: new Date().toISOString() };
      this.save();
      return this.db.payments[idx];
    }
    return null;
  }

  // Meta Connections
  public findMetaConnectionByUserId(userId: string): MetaConnection | undefined {
    const custom = this.db.meta_connections.find(m => m.user_id === userId);
    if (custom) return custom;

    // Use verified server-side META_ACCESS_TOKEN and verified Meta assets (Facebook Page, Instagram, SMAP Ads)
    const envToken = process.env.META_ACCESS_TOKEN?.trim();
    const fallbackToken = VERIFIED_META_ACCESS_TOKEN && VERIFIED_META_ACCESS_TOKEN.trim().length > 0 ? VERIFIED_META_ACCESS_TOKEN.trim() : null;
    const serverToken = (envToken && !envToken.startsWith('EAAPxe7cUc6MBSgRem'))
      ? envToken
      : (fallbackToken || envToken || null);
    if (serverToken && serverToken.length > 0) {
      return {
        id: `meta_conn_server_${userId || 'default'}`,
        user_id: userId,
        meta_user_id: '128670460329078',
        meta_user_name: 'Sahil Gupta',
        access_token: serverToken,
        token_expires_at: new Date(Date.now() + 60 * 24 * 3600 * 1000).toISOString(),
        ad_accounts: [
          {
            id: 'act_1627260695520511',
            account_id: '1627260695520511',
            name: 'SMAP Ads',
            currency: 'INR',
            account_status: 1,
          },
        ],
        selected_ad_account_id: 'act_1627260695520511',
        pages: [
          {
            id: '128670460329078',
            name: 'Sahil Gupta',
            category: 'Business',
            tasks: ['MANAGE', 'ADVERTISE'],
            instagram_account_id: '17841445164423927',
            instagram_username: 'ravi105065',
          },
        ],
        selected_page_id: '128670460329078',
        page_id: '128670460329078',
        page_name: 'Sahil Gupta',
        instagram_accounts: [
          {
            id: '17841445164423927',
            username: 'ravi105065',
            name: 'ravi105065',
            page_id: '128670460329078',
          },
        ],
        selected_instagram_id: '17841445164423927',
        instagram_id: '17841445164423927',
        instagram_username: 'ravi105065',
        is_server_verified: true,
        created_at: '2026-10-08T13:41:00.000Z',
        updated_at: new Date().toISOString(),
      };
    }

    return undefined;
  }
  public saveMetaConnection(connection: MetaConnection) {
    const idx = this.db.meta_connections.findIndex(m => m.user_id === connection.user_id);
    if (idx !== -1) {
      this.db.meta_connections[idx] = { ...connection, updated_at: new Date().toISOString() };
    } else {
      this.db.meta_connections.push(connection);
    }
    this.save();
    return connection;
  }
  public deleteMetaConnection(userId: string) {
    this.db.meta_connections = this.db.meta_connections.filter(m => m.user_id !== userId);
    this.save();
  }

  // Support Tickets
  public getTickets(userId?: string) {
    if (userId) {
      return this.db.support_tickets.filter(t => t.user_id === userId);
    }
    return this.db.support_tickets;
  }
  public findTicketById(id: string) { return this.db.support_tickets.find(t => t.id === id); }
  public createTicket(ticket: SupportTicket) {
    this.db.support_tickets.unshift(ticket);
    this.save();
    return ticket;
  }
  public updateTicket(id: string, updates: Partial<SupportTicket>) {
    const idx = this.db.support_tickets.findIndex(t => t.id === id);
    if (idx !== -1) {
      this.db.support_tickets[idx] = { ...this.db.support_tickets[idx], ...updates, updated_at: new Date().toISOString() };
      this.save();
      return this.db.support_tickets[idx];
    }
    return null;
  }
  public addTicketReply(ticketId: string, reply: SupportTicketReply) {
    const ticket = this.findTicketById(ticketId);
    if (ticket) {
      ticket.replies.push(reply);
      ticket.updated_at = new Date().toISOString();
      this.save();
      return ticket;
    }
    return null;
  }

  // System Logs getter
  public getLogs(limit = 100) {
    return this.db.system_logs.slice(0, limit);
  }

  // --- Customer Wallet & Transactions ---
  public getWalletBalance(userId: string): number {
    const user = this.findUserById(userId);
    if (!user) return 0;
    return typeof user.wallet_balance === 'number' && !isNaN(user.wallet_balance)
      ? Math.max(0, Math.round(user.wallet_balance * 100) / 100)
      : 0;
  }

  public getWalletTransactions(userId?: string): WalletTransaction[] {
    if (!Array.isArray(this.db.wallet_transactions)) {
      this.db.wallet_transactions = [];
    }
    if (userId) {
      return this.db.wallet_transactions.filter((tx) => tx.user_id === userId);
    }
    return this.db.wallet_transactions;
  }

  public findWalletTransactionById(id: string): WalletTransaction | undefined {
    return this.db.wallet_transactions.find((tx) => tx.id === id);
  }

  public findWalletTransactionByPaymentId(paymentId: string): WalletTransaction | undefined {
    return this.db.wallet_transactions.find((tx) => tx.payment_id === paymentId && tx.status === 'SUCCESS');
  }

  public findWalletTransactionByGatewayPaymentId(gatewayPaymentId: string): WalletTransaction | undefined {
    return this.db.wallet_transactions.find((tx) => tx.gateway_payment_id === gatewayPaymentId && tx.status === 'SUCCESS');
  }

  public findWalletTransactionByGatewayOrderId(gatewayOrderId: string): WalletTransaction | undefined {
    return this.db.wallet_transactions.find((tx) => tx.gateway_order_id === gatewayOrderId && tx.status === 'SUCCESS');
  }

  public createWalletTransaction(tx: WalletTransaction): WalletTransaction {
    if (!Array.isArray(this.db.wallet_transactions)) {
      this.db.wallet_transactions = [];
    }
    this.db.wallet_transactions.unshift(tx);
    this.save();
    return tx;
  }

  /**
   * Credit customer wallet atomically and record an ADD_FUNDS transaction.
   * Guarantees that wallet balance is updated strictly in the backend database.
   */
  public creditWallet(
    userId: string,
    amount: number,
    meta: {
      description: string;
      paymentId?: string;
      gatewayPaymentId?: string;
      gatewayOrderId?: string;
      status?: WalletTransactionStatus;
    }
  ): { newBalance: number; transaction: WalletTransaction } {
    const user = this.findUserById(userId);
    if (!user) {
      throw new Error(`User ${userId} not found`);
    }

    const currentBalance = typeof user.wallet_balance === 'number' && !isNaN(user.wallet_balance)
      ? user.wallet_balance
      : 0;

    // Strict Double-Layer Database Idempotency Guard: Never credit duplicate payment or gateway payment ID
    if (meta.paymentId) {
      const existingByPayment = this.findWalletTransactionByPaymentId(meta.paymentId);
      if (existingByPayment && existingByPayment.status === 'SUCCESS') {
        this.log('PAYMENT', 'INFO', `Idempotency guard prevented double-credit for payment ${meta.paymentId}`, {
          userId,
          paymentId: meta.paymentId,
          existingTxId: existingByPayment.id,
        });
        return { newBalance: currentBalance, transaction: existingByPayment };
      }
    }
    if (meta.gatewayPaymentId) {
      const existingByGateway = this.findWalletTransactionByGatewayPaymentId(meta.gatewayPaymentId);
      if (existingByGateway && existingByGateway.status === 'SUCCESS') {
        this.log('PAYMENT', 'INFO', `Idempotency guard prevented double-credit for gateway payment ${meta.gatewayPaymentId}`, {
          userId,
          gatewayPaymentId: meta.gatewayPaymentId,
          existingTxId: existingByGateway.id,
        });
        return { newBalance: currentBalance, transaction: existingByGateway };
      }
    }

    const roundedAmount = Math.max(0, Math.round(amount * 100) / 100);
    const newBalance = Math.round((currentBalance + roundedAmount) * 100) / 100;

    const tx: WalletTransaction = {
      id: `wtx_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
      user_id: userId,
      type: 'ADD_FUNDS',
      amount: roundedAmount,
      balance_before: currentBalance,
      balance_after: newBalance,
      description: meta.description,
      payment_id: meta.paymentId || null,
      gateway_payment_id: meta.gatewayPaymentId || null,
      gateway_order_id: meta.gatewayOrderId || null,
      campaign_id: null,
      status: meta.status || 'SUCCESS',
      created_at: new Date().toISOString(),
    };

    user.wallet_balance = newBalance;
    user.updated_at = new Date().toISOString();
    this.createWalletTransaction(tx);
    this.save();

    this.log('PAYMENT', 'INFO', `Credited ₹${roundedAmount} to wallet for user ${userId}. New balance: ₹${newBalance}`, {
      userId,
      amount: roundedAmount,
      balanceBefore: currentBalance,
      balanceAfter: newBalance,
      txId: tx.id,
      paymentId: meta.paymentId,
    });

    return { newBalance, transaction: tx };
  }

  /**
   * One-time promotional credit allocation strictly for verified Owner/Admin account (sahil272025@gmail.com).
   * Strict double-layer idempotency: checks both user.promotional_credit_granted flag and existing ledger transactions.
   * Completely independent of Razorpay payment records and non-withdrawable.
   */
  public checkAndGrantOwnerPromotionalCredit(userId: string): {
    granted: boolean;
    amount: number;
    newBalance: number;
    alreadyGranted: boolean;
    transaction?: WalletTransaction;
  } {
    const user = this.findUserById(userId);
    if (!user) {
      return { granted: false, amount: 0, newBalance: 0, alreadyGranted: false };
    }

    // Strict identity verification: Only the verified owner account is eligible
    const cleanEmail = user.email.trim().toLowerCase();
    if (cleanEmail !== 'sahil272025@gmail.com') {
      return { granted: false, amount: 0, newBalance: user.wallet_balance || 0, alreadyGranted: false };
    }

    // Idempotency Check: verify if already granted via flag or existing transaction
    const existingTx = (this.db.wallet_transactions || []).find(
      (tx) => tx.user_id === userId && tx.type === 'PROMOTIONAL_CREDIT'
    );

    if (user.promotional_credit_granted || existingTx) {
      if (!user.promotional_credit_granted) {
        user.promotional_credit_granted = true;
        this.save();
      }
      return {
        granted: false,
        amount: 0,
        newBalance: user.wallet_balance || 0,
        alreadyGranted: true,
        transaction: existingTx,
      };
    }

    // Atomically allocate the ₹50,000 promotional credit
    const promoAmount = 50000;
    const currentBalance = typeof user.wallet_balance === 'number' && !isNaN(user.wallet_balance)
      ? user.wallet_balance
      : 0;
    const newBalance = Math.round((currentBalance + promoAmount) * 100) / 100;

    const tx: WalletTransaction = {
      id: `wtx_promo_owner_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
      user_id: userId,
      type: 'PROMOTIONAL_CREDIT',
      amount: promoAmount,
      balance_before: currentBalance,
      balance_after: newBalance,
      description: 'Owner Promotional Advertising Credit — Authorized for campaign creation and ad testing (Non-withdrawable)',
      payment_id: null,
      gateway_payment_id: null,
      gateway_order_id: null,
      campaign_id: null,
      status: 'SUCCESS',
      created_at: new Date().toISOString(),
    };

    user.wallet_balance = newBalance;
    user.promotional_credit_granted = true;
    user.role = 'admin'; // Owner is always admin
    user.updated_at = new Date().toISOString();

    this.createWalletTransaction(tx);
    this.save();

    this.log('ADMIN', 'INFO', `Allocated one-time owner promotional credit of ₹${promoAmount} to verified owner ${user.email}. New balance: ₹${newBalance}`, {
      userId,
      amount: promoAmount,
      balanceBefore: currentBalance,
      balanceAfter: newBalance,
      txId: tx.id,
    });

    return {
      granted: true,
      amount: promoAmount,
      newBalance,
      alreadyGranted: false,
      transaction: tx,
    };
  }

  /**
   * Reset/reconcile unverified or test wallet balance back to ₹0 with an audit ledger entry.
   * Safety guard: Throws if customer has verified PAID payments unless explicitly overridden.
   */
  public resetWalletBalance(userId: string, reason?: string): {
    previousBalance: number;
    newBalance: number;
    transaction: WalletTransaction;
  } {
    const user = this.findUserById(userId);
    if (!user) {
      throw new Error(`User ${userId} not found`);
    }

    const verifiedPayments = (this.db.payments || []).filter(
      (p) => p.user_id === userId && p.status === 'PAID'
    );
    if (verifiedPayments.length > 0 && !reason?.includes('CONFIRMED_OVERRIDE')) {
      throw new Error(
        `Cannot reset wallet: customer has ${verifiedPayments.length} verified real payment(s). Resetting verified funds is prohibited. Use Admin Balance Reconciliation instead.`
      );
    }

    const currentBalance = typeof user.wallet_balance === 'number' && !isNaN(user.wallet_balance)
      ? user.wallet_balance
      : 0;

    const tx: WalletTransaction = {
      id: `wtx_adj_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
      user_id: userId,
      type: 'REFUND',
      amount: currentBalance,
      balance_before: currentBalance,
      balance_after: 0,
      description: reason || `Audit Adjustment: Reset test balance of ₹${currentBalance.toFixed(2)} to ₹0.00`,
      payment_id: null,
      gateway_payment_id: null,
      gateway_order_id: null,
      campaign_id: null,
      status: 'SUCCESS',
      created_at: new Date().toISOString(),
    };

    user.wallet_balance = 0;
    user.updated_at = new Date().toISOString();
    this.createWalletTransaction(tx);
    this.save();

    this.log('PAYMENT', 'WARN', `Reset wallet balance for user ${userId} from ₹${currentBalance} to ₹0.00`, {
      userId,
      previousBalance: currentBalance,
      reason,
    });

    return { previousBalance: currentBalance, newBalance: 0, transaction: tx };
  }

  /**
   * Reconciles customer wallet against verified Razorpay payments and debit transactions.
   * Restores legitimate customer balances if wiped out or undercredited by test resets,
   * with complete audit logging and transaction traceability.
   */
  public reconcileAndRestoreLegitimateBalance(
    userId: string,
    adminUserId: string = 'system_admin',
    auditReason?: string
  ): {
    userId: string;
    previousBalance: number;
    restoredBalance: number;
    correctionAmount: number;
    verifiedPayments: Array<{ id: string; gatewayPaymentId: string | null; amount: number; verifiedAt: string | null }>;
    totalVerifiedCredits: number;
    totalLegitimateDebits: number;
    transaction: WalletTransaction | null;
    status: 'RESTORED' | 'ALREADY_RECONCILED';
  } {
    const user = this.findUserById(userId);
    if (!user) {
      throw new Error(`User ${userId} not found`);
    }

    const currentBalance = typeof user.wallet_balance === 'number' && !isNaN(user.wallet_balance)
      ? user.wallet_balance
      : 0;

    // 1. Calculate sum of verified PAID payments (Razorpay live payments)
    const verifiedPayments = (this.db.payments || [])
      .filter((p) => p.user_id === userId && p.status === 'PAID')
      .map((p) => ({
        id: p.id,
        gatewayPaymentId: p.gateway_payment_id || null,
        amount: typeof p.amount === 'number' ? p.amount : 0,
        verifiedAt: p.verified_at || null,
      }));

    const totalVerifiedCredits = Math.round(
      verifiedPayments.reduce((sum, p) => sum + p.amount, 0) * 100
    ) / 100;

    // 2. Calculate sum of legitimate debits (successful campaign payments)
    const legitimateDebits = (this.db.wallet_transactions || [])
      .filter((tx) => tx.user_id === userId && tx.type === 'CAMPAIGN_PAYMENT' && tx.status === 'SUCCESS')
      .map((tx) => (typeof tx.amount === 'number' ? tx.amount : 0));

    const totalLegitimateDebits = Math.round(
      legitimateDebits.reduce((sum, amt) => sum + amt, 0) * 100
    ) / 100;

    // Legitimate ledger target balance
    const targetLegitimateBalance = Math.max(
      0,
      Math.round((totalVerifiedCredits - totalLegitimateDebits) * 100) / 100
    );

    // If balance is already equal to or greater than target, no upward adjustment needed
    if (currentBalance >= targetLegitimateBalance) {
      return {
        userId,
        previousBalance: currentBalance,
        restoredBalance: currentBalance,
        correctionAmount: 0,
        verifiedPayments,
        totalVerifiedCredits,
        totalLegitimateDebits,
        transaction: null,
        status: 'ALREADY_RECONCILED',
      };
    }

    const correctionAmount = Math.round((targetLegitimateBalance - currentBalance) * 100) / 100;

    const paymentRefs = verifiedPayments
      .map((p) => p.gatewayPaymentId || p.id)
      .filter(Boolean)
      .join(', ');

    const description =
      auditReason ||
      `Admin Ledger Correction: Restored legitimate verified balance of ₹${correctionAmount.toFixed(
        2
      )} from Razorpay payment(s) [${paymentRefs || 'VERIFIED_PAYMENTS'}] reversing accidental balance reset.`;

    const latestPayment = verifiedPayments[verifiedPayments.length - 1];

    const tx: WalletTransaction = {
      id: `wtx_corr_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
      user_id: userId,
      type: 'AUDIT_CORRECTION',
      amount: correctionAmount,
      balance_before: currentBalance,
      balance_after: targetLegitimateBalance,
      description,
      payment_id: latestPayment?.id || null,
      gateway_payment_id: latestPayment?.gatewayPaymentId || null,
      gateway_order_id: null,
      campaign_id: null,
      status: 'SUCCESS',
      created_at: new Date().toISOString(),
    };

    user.wallet_balance = targetLegitimateBalance;
    user.updated_at = new Date().toISOString();
    this.createWalletTransaction(tx);
    this.save();

    this.log(
      'PAYMENT',
      'INFO',
      `Restored legitimate wallet balance for user ${userId} to ₹${targetLegitimateBalance} (+₹${correctionAmount})`,
      {
        userId,
        adminUserId,
        previousBalance: currentBalance,
        restoredBalance: targetLegitimateBalance,
        correctionAmount,
        verifiedCredits: totalVerifiedCredits,
        legitimateDebits: totalLegitimateDebits,
        paymentCount: verifiedPayments.length,
        txId: tx.id,
      }
    );

    this.log(
      'ADMIN',
      'INFO',
      `Admin ${adminUserId} executed balance reconciliation for user ${userId}. Restored ₹${correctionAmount} to wallet.`,
      {
        userId,
        adminUserId,
        txId: tx.id,
        reason: auditReason,
      }
    );

    return {
      userId,
      previousBalance: currentBalance,
      restoredBalance: targetLegitimateBalance,
      correctionAmount,
      verifiedPayments,
      totalVerifiedCredits,
      totalLegitimateDebits,
      transaction: tx,
      status: 'RESTORED',
    };
  }

  /**
   * Deduct funds atomically from customer wallet for a campaign launch/payment.
   * Never trusts client-side assertions. Verifies sufficient funds in database.
   */
  public deductWallet(
    userId: string,
    amount: number,
    meta: {
      description: string;
      campaignId?: string;
    }
  ): { newBalance: number; transaction: WalletTransaction } {
    const user = this.findUserById(userId);
    if (!user) {
      throw new Error(`User ${userId} not found`);
    }

    const currentBalance = typeof user.wallet_balance === 'number' && !isNaN(user.wallet_balance)
      ? user.wallet_balance
      : 0;

    // Strict Double-Layer Idempotency Guard: Never deduct twice for the same campaign order
    if (meta.campaignId) {
      const existingTx = this.db.wallet_transactions.find(
        (t) => t.campaign_id === meta.campaignId && t.type === 'CAMPAIGN_PAYMENT' && t.status === 'SUCCESS'
      );
      if (existingTx) {
        this.log('PAYMENT', 'WARN', `Idempotency guard prevented double deduction for campaign ${meta.campaignId}`, {
          userId,
          campaignId: meta.campaignId,
          existingTxId: existingTx.id,
        });
        return { newBalance: currentBalance, transaction: existingTx };
      }
    }

    const roundedAmount = Math.max(0, Math.round(amount * 100) / 100);

    if (currentBalance < roundedAmount) {
      throw new Error(`Insufficient balance. Please Add Funds to continue. Current balance: ₹${currentBalance}, Required: ₹${roundedAmount}`);
    }

    const newBalance = Math.round((currentBalance - roundedAmount) * 100) / 100;

    const tx: WalletTransaction = {
      id: `wtx_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
      user_id: userId,
      type: 'CAMPAIGN_PAYMENT',
      amount: roundedAmount,
      balance_before: currentBalance,
      balance_after: newBalance,
      description: meta.description,
      payment_id: null,
      gateway_payment_id: null,
      gateway_order_id: null,
      campaign_id: meta.campaignId || null,
      status: 'SUCCESS',
      created_at: new Date().toISOString(),
    };

    user.wallet_balance = newBalance;
    user.updated_at = new Date().toISOString();
    this.createWalletTransaction(tx);
    this.save();

    this.log('PAYMENT', 'INFO', `Deducted ₹${roundedAmount} from wallet for user ${userId}. New balance: ₹${newBalance}`, {
      userId,
      amount: roundedAmount,
      balanceBefore: currentBalance,
      balanceAfter: newBalance,
      campaignId: meta.campaignId,
      txId: tx.id,
    });

    return { newBalance, transaction: tx };
  }

  /**
   * Record a failed or cancelled payment attempt in transaction ledger for transparency,
   * without affecting the customer's wallet balance.
   */
  public recordFailedWalletTransaction(
    userId: string,
    amount: number,
    meta: {
      description: string;
      paymentId?: string;
      gatewayPaymentId?: string;
      failureReason?: string;
    }
  ): WalletTransaction {
    const currentBalance = this.getWalletBalance(userId);
    const tx: WalletTransaction = {
      id: `wtx_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
      user_id: userId,
      type: 'FAILED_PAYMENT',
      amount: Math.max(0, Math.round(amount * 100) / 100),
      balance_before: currentBalance,
      balance_after: currentBalance,
      description: meta.failureReason
        ? `${meta.description} (Reason: ${meta.failureReason})`
        : meta.description,
      payment_id: meta.paymentId || null,
      gateway_payment_id: meta.gatewayPaymentId || null,
      gateway_order_id: null,
      campaign_id: null,
      status: 'FAILED',
      created_at: new Date().toISOString(),
    };

    this.createWalletTransaction(tx);
    return tx;
  }

  /**
   * Aggregates platform wallet statistics and customer ledgers for Admin overview.
   */
  public getAdminWalletOverview() {
    const users = this.getUsers().filter((u) => u && u.role !== 'admin');
    const transactions = this.getWalletTransactions();

    let totalPlatformBalance = 0;
    let totalFundsAdded = 0;
    let totalFundsUsed = 0;

    const customers = users.map((u) => {
      const balance = typeof u.wallet_balance === 'number' && !isNaN(u.wallet_balance) ? u.wallet_balance : 0;
      totalPlatformBalance += balance;

      const userTxs = transactions.filter((tx) => tx.user_id === u.id);
      const added = userTxs
        .filter((tx) => tx.type === 'ADD_FUNDS' && tx.status === 'SUCCESS')
        .reduce((sum, tx) => sum + tx.amount, 0);
      const used = userTxs
        .filter((tx) => tx.type === 'CAMPAIGN_PAYMENT' && tx.status === 'SUCCESS')
        .reduce((sum, tx) => sum + tx.amount, 0);

      totalFundsAdded += added;
      totalFundsUsed += used;

      const lastTx = userTxs[0];

      return {
        userId: u.id,
        name: u.name,
        email: u.email,
        phone: u.phone,
        currentBalance: Math.round(balance * 100) / 100,
        totalFundsAdded: Math.round(added * 100) / 100,
        totalFundsUsed: Math.round(used * 100) / 100,
        transactionsCount: userTxs.length,
        lastActivityAt: lastTx ? lastTx.created_at : u.created_at,
      };
    });

    return {
      summary: {
        totalPlatformBalance: Math.round(totalPlatformBalance * 100) / 100,
        totalFundsAdded: Math.round(totalFundsAdded * 100) / 100,
        totalFundsUsed: Math.round(totalFundsUsed * 100) / 100,
        totalTransactions: transactions.length,
      },
      customers,
      transactions,
    };
  }
}

export const db = new DatabaseService();
