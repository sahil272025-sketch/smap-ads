import express, { Request, Response, NextFunction } from 'express';
import crypto from 'crypto';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { db, User } from './db.js';
import { AuthService, AuthSessionPayload } from './authService.js';
import { PaymentService } from './paymentService.js';
import { MetaService } from './metaService.js';
import { CampaignService } from './campaignService.js';
import { SupportService } from './supportService.js';
import { WalletService } from './walletService.js';
import { CampaignQueueService } from './campaignQueue.js';

export const apiRouter = express.Router();

// File upload configuration using multer
const DEFAULT_DATA_DIR = path.resolve(process.cwd(), 'data');
const DATA_DIR = process.env.RENDER_DISK_PATH ||
  process.env.DATA_DIR ||
  (fs.existsSync('/var/data') ? '/var/data' : DEFAULT_DATA_DIR);
const uploadDir = path.join(DATA_DIR, 'uploads');
const chunkDir = path.join(uploadDir, 'chunks');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}
if (!fs.existsSync(chunkDir)) {
  fs.mkdirSync(chunkDir, { recursive: true });
}

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, uploadDir);
  },
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const cleanBase = path.basename(file.originalname, ext).replace(/[^a-zA-Z0-9]/g, '_');
    cb(null, `${cleanBase}_${Date.now()}${ext}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 512 * 1024 * 1024 }, // 512MB max for high-resolution 1080p 70s videos and lossless images
  fileFilter: (_req, file, cb) => {
    const allowed = /jpeg|jpg|png|webp|mp4|mov|webm|quicktime/i;
    const ext = path.extname(file.originalname).toLowerCase().replace('.', '');
    const mime = file.mimetype.toLowerCase();
    if (allowed.test(ext) || allowed.test(mime)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file format. High-resolution images (JPG, JPEG, PNG, WEBP) and videos (MP4, MOV) up to 70s are supported.'));
    }
  },
});

const chunkStorage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, chunkDir);
  },
  filename: (req, _file, cb) => {
    const uploadId = String(req.body.uploadId || 'temp').replace(/[^a-zA-Z0-9_-]/g, '');
    const chunkIndex = String(req.body.chunkIndex || '0').replace(/[^0-9]/g, '');
    cb(null, `${uploadId}_chunk_${chunkIndex}`);
  },
});

const chunkUpload = multer({
  storage: chunkStorage,
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB per chunk slice
});

// Auth Middleware
export interface AuthenticatedRequest extends Request {
  user?: User;
  tokenPayload?: AuthSessionPayload;
}

export function getRequestOrigin(req: Request): string {
  // 1. Check referer (common for browser GET requests like /api/auth/google/url)
  const referer = req.get('referer');
  if (referer) {
    try {
      const parsed = new URL(referer);
      if (parsed.host && !parsed.host.includes('localhost:3000')) {
        return `${parsed.protocol}//${parsed.host}`;
      }
    } catch {
      // ignore
    }
  }

  // 2. Check origin header (standard for POST/CORS requests)
  const origin = req.get('origin');
  if (origin && !origin.includes('localhost:3000')) {
    return origin;
  }

  // 3. Check x-forwarded-host or host headers
  const forwardedProto = req.get('x-forwarded-proto') || (req.secure ? 'https' : 'http');
  const forwardedHost = req.get('x-forwarded-host') || req.get('host');
  if (forwardedHost && !forwardedHost.includes('localhost:3000')) {
    return `${forwardedProto}://${forwardedHost}`;
  }

  // 4. Default to configured APP_URL or production Render URL
  if (process.env.APP_URL && !process.env.APP_URL.includes('ais-dev')) {
    return process.env.APP_URL.trim().replace(/\/$/, '');
  }

  return 'https://smap-ads.onrender.com';
}

export const requireAuth = (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  const authHeader = req.headers.authorization;
  let token: string | null = null;

  if (authHeader && authHeader.startsWith('Bearer ')) {
    token = authHeader.split(' ')[1];
  } else if (req.cookies && req.cookies.smap_session) {
    token = req.cookies.smap_session;
  } else if (req.cookies && req.cookies.smap_token) {
    token = req.cookies.smap_token;
  }

  if (!token) {
    return res.status(401).json({ error: 'Authentication required. Please sign in with Google.' });
  }

  const payload = AuthService.verifySessionToken(token);
  if (!payload) {
    return res.status(401).json({ error: 'Session expired or invalid token. Please sign in with Google again.' });
  }

  let user = db.findUserById(payload.userId);
  if (!user && payload.email) {
    user = db.findUserByEmail(payload.email);
  }
  if (!user && payload.googleSub) {
    user = db.findUserByGoogleSub(payload.googleSub);
  }
  if (!user && payload.email) {
    // Self-healing: reconstruct user session from verified cryptographic JWT payload
    const { user: restoredUser } = AuthService.findOrCreateGoogleUser({
      sub: payload.googleSub || '',
      email: payload.email,
      name: payload.email.split('@')[0],
      email_verified: true,
      picture: null,
    });
    user = restoredUser;
  }

  if (!user) {
    return res.status(401).json({ error: 'Customer account not found.' });
  }

  if (user.status === 'SUSPENDED') {
    return res.status(403).json({ error: 'Your SMAP account is suspended. Please contact support.' });
  }

  req.user = user;
  req.tokenPayload = payload;
  next();
};

export const requireAdmin = (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  requireAuth(req, res, () => {
    if (req.user?.role !== 'admin') {
      return res.status(403).json({ error: 'Access restricted to administrators only.' });
    }
    next();
  });
};

// ==========================================
// 1. PUBLIC & CONFIG
// ==========================================
apiRouter.get('/config', (req, res) => {
  const reqOrigin = getRequestOrigin(req);
  const metaConfig = MetaService.getConfigStatus(reqOrigin);
  const paymentStatus = PaymentService.getGatewayStatus();
  const googleConfig = AuthService.getGoogleConfigStatus(reqOrigin);

  res.json({
    appName: 'SMAP',
    brandName: 'SMAP (Sahil Marketing Ads Powerful)',
    platforms: ['Facebook', 'Instagram'],
    merchantUpi: paymentStatus.merchantUpi,
    paymentStatus,
    googleConfig,
    metaStatus: {
      isConfigured: metaConfig.isConfigured,
      apiVersion: metaConfig.apiVersion,
      statusMessage: metaConfig.statusMessage,
    },
  });
});

apiRouter.get('/packages', (_req, res) => {
  const packages = db.getPackages(true);
  res.json({ packages });
});

// ==========================================
// 2. REAL GOOGLE AUTHENTICATION ONLY
// ==========================================
apiRouter.get('/auth/google/config', (req, res) => {
  const status = AuthService.getGoogleConfigStatus(getRequestOrigin(req));
  res.json(status);
});

function renderAuthResultPage(res: Response, {
  success,
  token,
  user,
  error,
}: {
  success: boolean;
  token?: string;
  user?: User;
  error?: string;
}) {
  const safeError = error || 'Authentication could not be completed.';
  const redirectUrl = success ? '/?tab=dashboard' : `/?tab=home&auth_error=${encodeURIComponent(safeError)}&open_auth=true`;

  if (success && token) {
    // Set secure HTTP-only session cookie for top-level navigation
    res.cookie('smap_session', token, {
      httpOnly: true,
      secure: true,
      sameSite: 'lax',
      path: '/',
      maxAge: 7 * 24 * 3600 * 1000,
    });
    res.cookie('smap_token', token, {
      httpOnly: false,
      secure: true,
      sameSite: 'lax',
      path: '/',
      maxAge: 7 * 24 * 3600 * 1000,
    });
  }

  // Handle JSON requests (e.g. automated tests or programmatic probes)
  const acceptsHtml = res.req.headers['accept']?.includes('text/html');
  const acceptsJson = res.req.headers['accept']?.includes('application/json');
  if (acceptsJson && !acceptsHtml) {
    if (success) {
      return res.json({ success: true, user, token, redirectUrl });
    } else {
      return res.status(400).json({ success: false, error: safeError, redirectUrl });
    }
  }

  // HTML response supporting both popup messaging and full-window redirect
  const html = `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${success ? 'SMAP — Authentication Successful' : 'SMAP — Authentication Notice'}</title>
  <meta http-equiv="refresh" content="${success ? '1' : '3'}; url=${redirectUrl}" />
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      background: #090D16;
      color: #F8FAFC;
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      margin: 0;
      padding: 16px;
    }
    .card {
      background: #0F172A;
      border: 1px solid ${success ? '#059669' : '#DC2626'};
      border-radius: 16px;
      padding: 32px;
      max-width: 440px;
      width: 100%;
      text-align: center;
      box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.5);
    }
    .icon {
      width: 48px;
      height: 48px;
      border-radius: 50%;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      font-size: 24px;
      margin-bottom: 16px;
      background: ${success ? 'rgba(16, 185, 129, 0.15)' : 'rgba(239, 68, 68, 0.15)'};
      color: ${success ? '#34D399' : '#F87171'};
    }
    h2 { margin: 0 0 8px 0; font-size: 20px; font-weight: 700; color: #FFFFFF; }
    p { margin: 0 0 20px 0; font-size: 14px; color: #94A3B8; line-height: 1.5; }
    .btn {
      display: inline-block;
      background: ${success ? '#4F46E5' : '#334155'};
      color: #FFFFFF;
      padding: 10px 20px;
      border-radius: 8px;
      text-decoration: none;
      font-size: 14px;
      font-weight: 600;
      transition: opacity 0.2s;
    }
    .btn:hover { opacity: 0.9; }
  </style>
</head>
<body>
  <div class="card">
    <div class="icon">${success ? '✓' : '⚠'}</div>
    <h2>${success ? 'Sign-In Successful' : 'Authentication Notice'}</h2>
    <p>${success ? 'Welcome back! Redirecting you to the SMAP Dashboard...' : safeError}</p>
    <a href="${redirectUrl}" class="btn">${success ? 'Open SMAP Dashboard' : 'Return to SMAP Login'}</a>
  </div>
  <script>
    try {
      if (window.opener && !window.opener.closed) {
        try {
          window.opener.postMessage(${JSON.stringify(
            success
              ? { type: 'GOOGLE_AUTH_SUCCESS', token, user }
              : { type: 'GOOGLE_AUTH_ERROR', error: safeError }
          )}, '*');
        } catch (_) {}
        setTimeout(function() {
          window.close();
          // If window.close() is blocked (e.g. mobile Chrome tabs), navigate current window to dashboard
          setTimeout(function() {
            window.location.replace(${JSON.stringify(redirectUrl)});
          }, 300);
        }, ${success ? 500 : 2500});
      } else {
        setTimeout(function() { window.location.replace(${JSON.stringify(redirectUrl)}); }, ${success ? 400 : 2500});
      }
    } catch (e) {
      window.location.replace(${JSON.stringify(redirectUrl)});
    }
  </script>
</body>
</html>`;

  res.send(html);
}

export const handleGoogleOAuthCallback = async (req: Request, res: Response) => {
  const body = req.body || {};
  const query = req.query || {};
  const credential = body.credential || query.credential;
  const { code, state, error, error_description } = (req.method === 'POST' ? body : query) || {};
  const isDevParam = req.query.dev === 'true' || body.dev === 'true';
  const savedState = req.cookies?.smap_oauth_state;

  // Handle DEV preview Google OAuth callback
  if (isDevParam) {
    db.log('AUTH', 'INFO', 'Received DEV preview Google OAuth callback');
    const devProfile = {
      sub: 'dev_google_preview_sub_101',
      email: 'sahilguptasahilgupta652@gmail.com',
      email_verified: true,
      name: 'Sahil Gupta',
      picture: null,
    };
    const { user, token } = AuthService.findOrCreateGoogleUser(devProfile);
    return renderAuthResultPage(res, {
      success: true,
      user,
      token,
    });
  }

  // 0. Handle Google Identity Services (GIS) redirect ID token credential
  if (credential) {
    db.log('AUTH', 'INFO', 'Received Google Identity Services redirect credential at callback');
    const result = await AuthService.verifyGoogleIdTokenDirect(String(credential));
    if (!result.success || !result.user || !result.token) {
      db.log('AUTH', 'WARN', `GIS credential verification failed: ${result.error}`);
      return renderAuthResultPage(res, {
        success: false,
        error: result.error || 'Google authentication failed.',
      });
    }

    db.log('AUTH', 'INFO', `User authenticated successfully via GIS: ${result.user.email}`);

    // Set secure HTTP-only session cookie for the domain with path: '/'
    res.cookie('smap_session', result.token, {
      httpOnly: true,
      secure: true,
      sameSite: 'lax',
      path: '/',
      maxAge: 7 * 24 * 3600 * 1000,
    });
    res.cookie('smap_token', result.token, {
      httpOnly: false,
      secure: true,
      sameSite: 'lax',
      path: '/',
      maxAge: 7 * 24 * 3600 * 1000,
    });

    // GIS redirect mode is a top-level browser POST from accounts.google.com.
    // HTTP 303 Post-Redirect-Get directly to the dashboard with both session cookies and token param ensures instant reliable rendering.
    return res.redirect(303, `/?tab=dashboard&auth_token=${encodeURIComponent(result.token)}`);
  }

  // 1. Direct route probe or health check (no OAuth query params provided)
  if (!code && !state && !error) {
    if (req.headers['accept']?.includes('application/json') || req.query.format === 'json') {
      return res.status(200).json({
        status: 'active',
        route: '/api/auth/google/callback',
        handler: 'google_oauth_callback',
        message: 'SMAP Google OAuth 2.0 callback endpoint is active and listening for Google authorization redirects.',
      });
    }
    return res.status(200).send(`<!doctype html>
<html lang="en">
<head><title>SMAP — Google OAuth Callback</title></head>
<body style="font-family: sans-serif; background: #090D16; color: #fff; padding: 40px; text-align: center;">
  <h2>SMAP Google OAuth 2.0 Callback Service</h2>
  <p style="color: #94a3b8;">This server endpoint is registered and ready to receive OAuth authorization codes from Google.</p>
  <a href="/?tab=dashboard" style="display: inline-block; margin-top: 16px; background: #4f46e5; color: #fff; padding: 10px 20px; border-radius: 8px; text-decoration: none;">Go to SMAP Dashboard &rarr;</a>
</body>
</html>`);
  }

  // 2. Google returned an error or the user cancelled the OAuth consent screen
  if (error) {
    const errorMsg = String(error_description || error);
    db.log('AUTH', 'WARN', `Google OAuth callback reported error: ${errorMsg}`);
    res.clearCookie('smap_oauth_state');
    return renderAuthResultPage(res, {
      success: false,
      error: `Google Sign-In was cancelled or denied: ${errorMsg}`,
    });
  }

  // 3. Validate state parameter to protect against CSRF attacks
  const isValidState = AuthService.validateOAuthState(String(state || ''), savedState);
  if (!isValidState) {
    res.clearCookie('smap_oauth_state');
    db.log('AUTH', 'WARN', 'Google OAuth callback rejected: CSRF state parameter mismatch or expired');
    return renderAuthResultPage(res, {
      success: false,
      error: 'OAuth security verification failed: invalid or expired session state. Please try signing in again.',
    });
  }

  // State verified: clear the one-time state cookie
  res.clearCookie('smap_oauth_state');

  // 4. Validate authorization code presence
  if (!code) {
    return renderAuthResultPage(res, {
      success: false,
      error: 'Authorization code was missing from the Google callback.',
    });
  }

  // 5. Exchange authorization code securely on server
  const result = await AuthService.exchangeGoogleAuthCode(String(code), getRequestOrigin(req));

  if (!result.success || !result.user || !result.token) {
    const errorMsg = result.error || 'Google authentication failed';
    return renderAuthResultPage(res, {
      success: false,
      error: errorMsg,
    });
  }

  // 6. Complete login and redirect to SMAP Dashboard
  return renderAuthResultPage(res, {
    success: true,
    user: result.user,
    token: result.token,
  });
};

apiRouter.get('/auth/google/url', (req, res) => {
  const state = AuthService.generateOAuthState();

  // Set secure CSRF state cookie
  res.cookie('smap_oauth_state', state, {
    httpOnly: true,
    secure: true,
    sameSite: 'none',
    maxAge: 15 * 60 * 1000, // 15 minutes
  });

  const result = AuthService.getGoogleAuthUrl(state, getRequestOrigin(req));

  if (result.error || !result.url) {
    return res.status(400).json({
      error: result.error || 'Google Sign-In configuration required.',
      configured: false,
    });
  }

  if (result.devMode && result.token) {
    res.cookie('smap_session', result.token, {
      httpOnly: true,
      secure: true,
      sameSite: 'lax',
      path: '/',
      maxAge: 7 * 24 * 3600 * 1000,
    });
    res.cookie('smap_token', result.token, {
      httpOnly: false,
      secure: true,
      sameSite: 'lax',
      path: '/',
      maxAge: 7 * 24 * 3600 * 1000,
    });
  }

  res.json({
    url: result.url,
    configured: true,
    devMode: result.devMode,
    user: result.user,
    token: result.token,
  });
});

apiRouter.all(['/auth/google/callback', '/auth/google/callback/', '/api/auth/google/callback', '/api/auth/google/callback/'], handleGoogleOAuthCallback);

apiRouter.post('/auth/google/verify', async (req, res) => {
  const { idToken } = req.body;
  if (!idToken) {
    return res.status(400).json({ error: 'Google ID token is required' });
  }

  const result = await AuthService.verifyGoogleIdTokenDirect(idToken);
  if (!result.success || !result.user || !result.token) {
    return res.status(401).json({ error: result.error || 'Google authentication failed' });
  }

  res.cookie('smap_session', result.token, {
    httpOnly: true,
    secure: true,
    sameSite: 'lax',
    path: '/',
    maxAge: 7 * 24 * 3600 * 1000,
  });
  res.cookie('smap_token', result.token, {
    httpOnly: false,
    secure: true,
    sameSite: 'lax',
    path: '/',
    maxAge: 7 * 24 * 3600 * 1000,
  });

  res.json({ user: result.user, token: result.token });
});

// Existing Email/Password Authentication (Kept as secondary login method per requirement 5)
apiRouter.post('/auth/register', async (req, res) => {
  try {
    const result = await AuthService.registerWithEmailPassword(req.body);
    res.cookie('smap_session', result.token, {
      httpOnly: true,
      secure: true,
      sameSite: 'lax',
      path: '/',
      maxAge: 7 * 24 * 3600 * 1000,
    });
    res.cookie('smap_token', result.token, {
      httpOnly: false,
      secure: true,
      sameSite: 'lax',
      path: '/',
      maxAge: 7 * 24 * 3600 * 1000,
    });
    res.json({ user: result.user, token: result.token });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Registration failed' });
  }
});

apiRouter.post('/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const result = await AuthService.loginWithEmailPassword(email, password);
    res.cookie('smap_session', result.token, {
      httpOnly: true,
      secure: true,
      sameSite: 'lax',
      path: '/',
      maxAge: 7 * 24 * 3600 * 1000,
    });
    res.cookie('smap_token', result.token, {
      httpOnly: false,
      secure: true,
      sameSite: 'lax',
      path: '/',
      maxAge: 7 * 24 * 3600 * 1000,
    });
    res.json({ user: result.user, token: result.token });
  } catch (err: any) {
    res.status(401).json({ error: err.message || 'Invalid credentials' });
  }
});

apiRouter.get('/auth/me', requireAuth, (req: AuthenticatedRequest, res) => {
  const user = req.user!;
  const metaConnection = db.findMetaConnectionByUserId(user.id);
  const isOwner = user.email.trim().toLowerCase() === 'sahil272025@gmail.com';
  const promoClaimed = Boolean(
    user.promotional_credit_granted ||
    (isOwner && db.isOwnerPromotionalCreditClaimed(user.id, user.email))
  );
  const balance = db.getWalletBalance(user.id);

  res.json({
    user: {
      id: user.id,
      google_sub: user.google_sub,
      name: user.name,
      email: user.email,
      email_verified: user.email_verified,
      profile_picture: user.profile_picture,
      phone: user.phone,
      role: user.role,
      status: user.status,
      wallet_balance: balance,
      promotional_credit_granted: promoClaimed,
      language: user.language || 'en',
      created_at: user.created_at,
      last_login_at: user.last_login_at,
    },
    metaConnection: metaConnection ? {
      connected: true,
      meta_user_name: metaConnection.meta_user_name,
      ad_accounts: metaConnection.ad_accounts || [],
      selected_ad_account_id: metaConnection.selected_ad_account_id || (metaConnection.ad_accounts?.[0]?.id ?? null),
      pages: metaConnection.pages || [],
      selected_page_id: metaConnection.selected_page_id || metaConnection.page_id || (metaConnection.pages?.[0]?.id ?? null),
      instagram_accounts: metaConnection.instagram_accounts || [],
      selected_instagram_id: metaConnection.selected_instagram_id || metaConnection.instagram_id || (metaConnection.instagram_accounts?.[0]?.id ?? null),
      expires_at: metaConnection.token_expires_at,
      page_id: metaConnection.selected_page_id || metaConnection.page_id || metaConnection.pages?.[0]?.id,
      page_name: metaConnection.page_name || metaConnection.pages?.find(p => p.id === (metaConnection.selected_page_id || metaConnection.page_id))?.name || metaConnection.pages?.[0]?.name,
      instagram_id: metaConnection.selected_instagram_id || metaConnection.instagram_id || metaConnection.instagram_accounts?.[0]?.id,
      instagram_username: metaConnection.instagram_username || metaConnection.instagram_accounts?.find(ig => ig.id === (metaConnection.selected_instagram_id || metaConnection.instagram_id))?.username || metaConnection.instagram_accounts?.[0]?.username,
      ad_account_id: metaConnection.selected_ad_account_id || (metaConnection.ad_accounts?.[0]?.id ?? null),
      ad_account_name: metaConnection.ad_accounts?.find(a => a.id === metaConnection.selected_ad_account_id)?.name || metaConnection.ad_accounts?.[0]?.name,
      is_server_verified: metaConnection.is_server_verified ?? false,
    } : {
      connected: false,
    },
  });
});

apiRouter.put('/auth/profile', requireAuth, (req: AuthenticatedRequest, res) => {
  try {
    const updated = AuthService.updateProfile(req.user!.id, req.body);
    const promoClaimed = Boolean(
      updated.promotional_credit_granted ||
      (updated.role === 'admin' && db.isOwnerPromotionalCreditClaimed(updated.id, updated.email))
    );
    res.json({
      user: {
        id: updated.id,
        google_sub: updated.google_sub,
        name: updated.name,
        email: updated.email,
        email_verified: updated.email_verified,
        profile_picture: updated.profile_picture,
        phone: updated.phone,
        role: updated.role,
        status: updated.status,
        wallet_balance: db.getWalletBalance(updated.id),
        promotional_credit_granted: promoClaimed,
        language: updated.language || 'en',
        created_at: updated.created_at,
        last_login_at: updated.last_login_at,
      },
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Profile update failed' });
  }
});

apiRouter.post('/auth/logout', (_req, res) => {
  res.clearCookie('smap_session', { path: '/' });
  res.clearCookie('smap_token', { path: '/' });
  res.json({ success: true, message: 'Logged out successfully' });
});

// ==========================================
// 3. CAMPAIGNS & CREATIVES
// ==========================================
apiRouter.post('/campaigns/upload', requireAuth, (req, res) => {
  upload.single('creative')(req, res, (err: any) => {
    if (err) {
      if (err instanceof multer.MulterError) {
        if (err.code === 'LIMIT_FILE_SIZE') {
          return res.status(400).json({ error: 'File size exceeds server upload limit (512MB maximum).' });
        }
        return res.status(400).json({ error: err.message });
      }
      return res.status(400).json({ error: err.message || 'Media upload failed' });
    }
    if (!req.file) {
      return res.status(400).json({ error: 'No media file uploaded' });
    }

    const isVideo = /mp4|mov|webm|quicktime/i.test(path.extname(req.file.originalname));
    const fileUrl = `/api/uploads/${req.file.filename}`;

    res.json({
      url: fileUrl,
      filename: req.file.filename,
      originalName: req.file.originalname,
      size: req.file.size,
      type: isVideo ? 'video' : 'image',
    });
  });
});

// Resumable & Chunked Upload for High-Definition 1080p Videos
apiRouter.post('/campaigns/upload/chunk', requireAuth, (req, res) => {
  chunkUpload.single('chunk')(req, res, (err: any) => {
    if (err) {
      return res.status(400).json({ error: err.message || 'Chunk upload failed' });
    }
    if (!req.file) {
      return res.status(400).json({ error: 'No chunk file received' });
    }
    const uploadId = String(req.body.uploadId || '');
    const chunkIndex = Number(req.body.chunkIndex);
    const totalChunks = Number(req.body.totalChunks);

    res.json({
      success: true,
      uploadId,
      chunkIndex,
      totalChunks,
      size: req.file.size,
    });
  });
});

apiRouter.post('/campaigns/upload/complete', requireAuth, async (req, res) => {
  try {
    const { uploadId, totalChunks, filename, duration } = req.body;
    if (!uploadId || !totalChunks || !filename) {
      return res.status(400).json({ error: 'uploadId, totalChunks, and filename are required' });
    }
    const cleanUploadId = String(uploadId).replace(/[^a-zA-Z0-9_-]/g, '');
    const numChunks = Number(totalChunks);
    const ext = path.extname(filename).toLowerCase();
    const cleanBase = path.basename(filename, ext).replace(/[^a-zA-Z0-9]/g, '_');
    const finalFilename = `${cleanBase}_${Date.now()}${ext}`;
    const finalFilePath = path.join(uploadDir, finalFilename);

    // Verify all chunks exist
    for (let i = 0; i < numChunks; i++) {
      const chunkPath = path.join(chunkDir, `${cleanUploadId}_chunk_${i}`);
      if (!fs.existsSync(chunkPath)) {
        return res.status(400).json({ error: `Missing upload chunk ${i} of ${numChunks}. Please retry upload.` });
      }
    }

    // Write all chunks in order
    const writeStream = fs.createWriteStream(finalFilePath);
    for (let i = 0; i < numChunks; i++) {
      const chunkPath = path.join(chunkDir, `${cleanUploadId}_chunk_${i}`);
      const chunkBuffer = fs.readFileSync(chunkPath);
      writeStream.write(chunkBuffer);
      try {
        fs.unlinkSync(chunkPath);
      } catch {}
    }
    writeStream.end();

    const stat = fs.statSync(finalFilePath);
    const isVideo = /mp4|mov|webm|quicktime/i.test(ext);

    // Validate video duration server-side
    if (isVideo && typeof duration === 'number' && duration > 70.9) {
      try { fs.unlinkSync(finalFilePath); } catch {}
      return res.status(400).json({
        error: `Video duration is ${Math.round(duration)} seconds. Maximum allowed video duration is 1 minute 10 seconds (70 seconds). Please trim your video.`,
      });
    }

    const fileUrl = `/api/uploads/${finalFilename}`;
    res.json({
      url: fileUrl,
      filename: finalFilename,
      originalName: filename,
      size: stat.size,
      type: isVideo ? 'video' : 'image',
      duration: duration || undefined,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to assemble uploaded chunks' });
  }
});

apiRouter.post('/campaigns/upload/abort', requireAuth, (req, res) => {
  const uploadId = req.body?.uploadId;
  if (uploadId) {
    const cleanUploadId = String(uploadId).replace(/[^a-zA-Z0-9_-]/g, '');
    try {
      const files = fs.readdirSync(chunkDir);
      for (const f of files) {
        if (f.startsWith(`${cleanUploadId}_chunk_`)) {
          fs.unlinkSync(path.join(chunkDir, f));
        }
      }
    } catch {}
  }
  res.json({ success: true, message: 'Upload cancelled and temporary chunks removed' });
});

apiRouter.post('/campaigns', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const { campaign, payment, metaResult } = await CampaignService.createDraft(req.user!.id, req.body);
    res.status(201).json({ campaign, payment, metaResult });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Campaign creation failed' });
  }
});

apiRouter.post('/campaigns/checkout', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const result = await CampaignService.checkoutWithWallet(req.user!.id, req.body);
    res.status(201).json(result);
  } catch (err: any) {
    const currentBalance = req.user ? db.getWalletBalance(req.user.id) : 0;
    res.status(400).json({
      error: err.message || 'Campaign checkout failed',
      availableBalance: currentBalance,
    });
  }
});

apiRouter.get('/campaigns', requireAuth, (req: AuthenticatedRequest, res) => {
  const campaigns = db.getCampaigns(req.user!.id);
  const statusFilter = req.query.status as string;

  const filtered = statusFilter && statusFilter !== 'ALL'
    ? campaigns.filter(c => c.status === statusFilter)
    : campaigns;

  res.json({ campaigns: filtered });
});

apiRouter.get('/campaigns/:id', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const details = await CampaignService.getCampaignWithMetaMetrics(req.params.id, req.user!.role === 'admin' ? undefined : req.user!.id);
    res.json(details);
  } catch (err: any) {
    res.status(404).json({ error: err.message || 'Campaign not found' });
  }
});

apiRouter.post('/campaigns/:id/submit-meta', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const updated = await CampaignService.submitToMeta(req.params.id, req.user!.id);
    res.json({ campaign: updated });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Failed to submit campaign to Meta' });
  }
});

// Interactive Budget Resolution (Adjust Duration for ₹0, Top-up Media Budget, or Full Wallet Refund)
apiRouter.post('/campaigns/:id/adjust-budget', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const { action, topupAmount } = req.body;
    const campaignId = req.params.id;
    const campaign = db.findCampaignById(campaignId);
    if (!campaign) {
      return res.status(404).json({ error: 'Campaign not found' });
    }
    if (campaign.user_id !== req.user!.id && req.user!.role !== 'admin') {
      return res.status(403).json({ error: 'Unauthorized to adjust this campaign' });
    }

    const pkg = db.findPackageById(campaign.package_id);
    const platformFee = pkg?.platform_fee ?? campaign.budget_breakdown?.platform_fee ?? 200;
    const totalBudget = campaign.total_budget || pkg?.price || 549;
    const mediaSpend = (pkg?.price && totalBudget === pkg.price && pkg.media_spend)
      ? pkg.media_spend
      : (campaign.budget_breakdown?.media_spend && campaign.budget_breakdown.media_spend + platformFee === totalBudget)
      ? campaign.budget_breakdown.media_spend
      : Math.max(0, totalBudget - platformFee);
    const minBudgetInfo = await MetaService.getAdAccountMinimumBudget('1627260695520511', 'INR', 'IMPRESSIONS', campaign.objective);

    if (action === 'adjust_duration') {
      // Option 1: Adjust Duration to fit Meta minimum daily floor for ₹0 extra
      const newDuration = Math.max(1, Math.floor(mediaSpend / minBudgetInfo.minDailyBudget));
      const newDailyMediaSpend = mediaSpend / newDuration;
      const startDate = new Date();
      const endDate = new Date(startDate.getTime() + newDuration * 24 * 3600 * 1000);

      const updated = db.updateCampaign(campaignId, {
        duration_days: newDuration,
        daily_budget: Math.round(newDailyMediaSpend),
        start_at: startDate.toISOString(),
        end_at: endDate.toISOString(),
        status: 'PAYMENT_CONFIRMED',
        queue_status: 'QUEUED',
        error_details: null,
        rejection_reason: null,
        budget_breakdown: {
          platform_fee: platformFee,
          media_spend: mediaSpend,
          daily_media_spend: newDailyMediaSpend,
          min_daily_media_spend: minBudgetInfo.minDailyBudget,
          currency: 'INR',
          recommended_duration_days: newDuration,
          recommended_topup_amount: 0,
        },
        meta_status_message: `Duration adjusted to ${newDuration} days (₹${newDailyMediaSpend.toFixed(2)}/day media spend) with customer approval. Re-queued for Meta submission.`,
      });

      // Re-enqueue for background worker processing
      CampaignQueueService.enqueue(campaignId);

      return res.json({
        success: true,
        message: `Campaign duration adjusted to ${newDuration} days at ₹${newDailyMediaSpend.toFixed(2)}/day (meets Meta minimum floor). Re-submitted for review.`,
        campaign: updated,
      });
    }

    if (action === 'topup_budget') {
      // Option 2: Customer tops up wallet to maintain original duration
      const duration = campaign.duration_days || pkg?.duration_days || 14;
      const requiredTotalMedia = Math.ceil(duration * minBudgetInfo.minDailyBudget);
      const calculatedShortfall = Math.max(0, requiredTotalMedia - mediaSpend);
      const shortfall = typeof topupAmount === 'number' && topupAmount > 0 ? topupAmount : calculatedShortfall;
      const userBalance = db.getWalletBalance(req.user!.id);

      if (userBalance < shortfall) {
        return res.status(400).json({
          error: `Insufficient wallet balance for top-up. Required: ₹${shortfall}, Available: ₹${userBalance.toFixed(2)}. Please add funds to your wallet.`,
          requiredAmount: shortfall,
          availableBalance: userBalance,
        });
      }

      // Deduct shortfall from wallet
      db.deductWallet(req.user!.id, shortfall, {
        description: `Media Budget Top-up for Campaign ${campaign.id} (${duration} Days @ ₹${minBudgetInfo.minDailyBudget.toFixed(2)}/day)`,
        campaignId,
      });

      const newTotalBudget = (campaign.total_budget || totalBudget) + shortfall;
      const newMediaSpend = mediaSpend + shortfall;
      const newDailyMediaSpend = newMediaSpend / duration;

      const updated = db.updateCampaign(campaignId, {
        total_budget: newTotalBudget,
        daily_budget: Math.round(newDailyMediaSpend),
        status: 'PAYMENT_CONFIRMED',
        queue_status: 'QUEUED',
        error_details: null,
        rejection_reason: null,
        budget_breakdown: {
          platform_fee: platformFee,
          media_spend: newMediaSpend,
          daily_media_spend: newDailyMediaSpend,
          min_daily_media_spend: minBudgetInfo.minDailyBudget,
          currency: 'INR',
          recommended_duration_days: duration,
          recommended_topup_amount: 0,
        },
        meta_status_message: `Media budget topped up by ₹${shortfall}. Re-queued for Meta submission.`,
      });

      CampaignQueueService.enqueue(campaignId);

      return res.json({
        success: true,
        message: `Top-up of ₹${shortfall} completed. Campaign re-queued for Meta submission with verified minimum budget.`,
        campaign: updated,
      });
    }

    if (action === 'refund_to_wallet') {
      // Option 3: Full Refund to Customer Wallet
      const payment = db.findPaymentByCampaignId(campaignId);
      const refundAmount = payment?.amount || campaign.total_budget || 0;

      if (refundAmount > 0) {
        db.creditWallet(req.user!.id, refundAmount, {
          description: `Full Refund for Cancelled Campaign ${campaign.id}`,
          paymentId: campaignId,
          type: 'CAMPAIGN_REFUND',
        });
      }

      if (payment) {
        db.updatePayment(payment.id, {
          status: 'REFUNDED',
          notes: `Full refund of ₹${refundAmount} credited to customer wallet upon request.`,
        });
      }

      const updated = db.updateCampaign(campaignId, {
        status: 'FAILED',
        queue_status: 'COMPLETED',
        rejection_reason: `Cancelled and refunded ₹${refundAmount} to wallet upon customer request.`,
        error_details: `Refunded ₹${refundAmount} to wallet on ${new Date().toLocaleString()}`,
        meta_status_message: `Campaign cancelled. ₹${refundAmount} refunded in full to customer wallet.`,
      });

      return res.json({
        success: true,
        message: `₹${refundAmount} refunded in full to your wallet balance.`,
        campaign: updated,
      });
    }

    return res.status(400).json({ error: 'Invalid adjustment action. Supported: adjust_duration, topup_budget, refund_to_wallet' });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to adjust campaign budget' });
  }
});

// Authentic Live Meta Marketing API Performance Reports
apiRouter.get(['/reports/performance', '/campaigns/performance/reports'], requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const forceRefresh = req.query.force === 'true';
    const userId = req.user!.role === 'admin' && req.query.userId
      ? String(req.query.userId)
      : (req.user!.role === 'admin' && req.query.all === 'true' ? undefined : req.user!.id);

    const reports = await CampaignService.getPerformanceReports(userId, forceRefresh);
    res.json(reports);
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Failed to generate performance reports' });
  }
});

// Diagnostic Campaign Queue Status
apiRouter.get('/queue/status', requireAuth, (_req: AuthenticatedRequest, res) => {
  const stats = CampaignQueueService.getQueueStats();
  res.json({
    success: true,
    stats,
    timestamp: new Date().toISOString(),
  });
});

// ==========================================
// 4. PAYMENTS (REAL UPI PAYMENT GATEWAY ONLY)
// ==========================================
apiRouter.get('/payments/status', (_req, res) => {
  const status = PaymentService.getGatewayStatus();
  res.json(status);
});

apiRouter.get('/payments', requireAuth, (req: AuthenticatedRequest, res) => {
  const payments = db.getPayments(req.user!.id);
  res.json({ payments });
});

apiRouter.get('/payments/:id', requireAuth, (req: AuthenticatedRequest, res) => {
  const payment = db.findPaymentById(req.params.id);
  if (!payment) return res.status(404).json({ error: 'Payment not found' });
  if (req.user!.role !== 'admin' && payment.user_id !== req.user!.id) {
    return res.status(403).json({ error: 'Unauthorized' });
  }
  res.json({ payment });
});

// Prepare or refresh Razorpay live order before opening checkout
apiRouter.post('/payments/:id/prepare-order', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const payment = db.findPaymentById(req.params.id);
    if (!payment) return res.status(404).json({ error: 'Payment not found' });
    if (req.user!.role !== 'admin' && payment.user_id !== req.user!.id) {
      return res.status(403).json({ error: 'Unauthorized' });
    }

    const updated = await PaymentService.ensureGatewayOrder(req.params.id);
    res.json({ payment: updated });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Failed to prepare payment order' });
  }
});

// Independent Backend Payment Verification
apiRouter.post('/payments/:id/verify', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const { gatewayPaymentId, gatewayOrderId, gatewaySignature } = req.body;
    const result = await PaymentService.verifyPayment({
      paymentId: req.params.id,
      userId: req.user!.id,
      gatewayPaymentId,
      gatewayOrderId,
      gatewaySignature,
    });
    res.json(result);
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Payment verification failed' });
  }
});

// Sandbox Payment Simulation Endpoint (strictly for development sandbox flows)
apiRouter.post('/payments/:id/sandbox-simulate', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    if (process.env.NODE_ENV === 'production') {
      return res.status(403).json({ error: 'Sandbox simulation endpoints are strictly disabled in production.' });
    }

    const { status, failureReason } = req.body;
    const payment = db.findPaymentById(req.params.id);
    if (!payment) return res.status(404).json({ error: 'Payment not found' });
    if (payment.user_id !== req.user!.id && req.user!.role !== 'admin') {
      return res.status(403).json({ error: 'Unauthorized' });
    }

    // Never allow wallet balance credits via simulation
    if (payment.campaign_id === 'WALLET_TOPUP' || payment.package_id === 'wallet_topup') {
      return res.status(403).json({ error: 'Wallet funds cannot be credited through simulation endpoints.' });
    }

    if (status === 'PAID') {
      const result = await PaymentService.verifyPayment({
        paymentId: req.params.id,
        userId: req.user!.id,
        gatewayPaymentId: `pay_sandbox_${Date.now()}`,
        gatewayOrderId: payment.gateway_order_id || `order_sandbox_${payment.id}`,
      });
      return res.json(result);
    } else if (status === 'FAILED') {
      const updated = db.updatePayment(payment.id, {
        status: 'FAILED',
        failure_reason: failureReason || 'Customer cancelled UPI authorization in bank app.',
      });
      return res.json({ success: true, payment: updated });
    } else {
      // Pending
      const updated = db.updatePayment(payment.id, {
        status: 'PENDING',
      });
      return res.json({ success: true, payment: updated });
    }
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Simulation failed' });
  }
});

// Customer UTR Reference Submission (for fallback audit)
apiRouter.post('/payments/:id/submit-ref', requireAuth, (req: AuthenticatedRequest, res) => {
  try {
    const { transactionReference } = req.body;
    const payment = PaymentService.submitTransactionReference(req.params.id, req.user!.id, transactionReference);
    res.json({
      payment,
      message: 'Transaction reference recorded for gateway audit.',
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Failed to submit transaction reference' });
  }
});

// Real Payment Gateway Webhook Endpoint
apiRouter.post('/payments/webhook', async (req, res) => {
  const signature = (req.headers['x-razorpay-signature'] ||
    req.headers['x-payment-signature'] ||
    req.headers['x-webhook-signature']) as string;
  const rawBody = (req as any).rawBody ? (req as any).rawBody.toString('utf8') : JSON.stringify(req.body);

  try {
    const result = await PaymentService.processGatewayWebhook(req.body, signature, rawBody);
    res.json(result);
  } catch (err: any) {
    const statusCode = err.message === 'Invalid webhook signature' ? 401 : 400;
    res.status(statusCode).json({ error: err.message || 'Webhook processing failed' });
  }
});

// Sandbox Webhook Simulator (Programmatic test runner for sandbox webhooks & idempotency)
apiRouter.post('/payments/sandbox/simulate-webhook', (req, res) => {
  if (process.env.NODE_ENV === 'production') {
    return res.status(403).json({ error: 'Sandbox webhook simulation is strictly disabled in production.' });
  }

  const { paymentId, event, amount, failureReason, invalidSignature } = req.body;
  const payment = db.findPaymentById(paymentId);
  if (!payment) {
    return res.status(404).json({ error: `Payment ${paymentId} not found` });
  }

  // Never allow wallet balance credits via simulated webhook
  if (payment.campaign_id === 'WALLET_TOPUP' || payment.package_id === 'wallet_topup') {
    return res.status(403).json({ error: 'Wallet funds cannot be credited through simulated webhooks. Genuine Razorpay webhook required.' });
  }

  const gatewayPaymentId = `pay_sandbox_wh_${Date.now()}`;
  const webhookBody = {
    event: event || 'payment.captured',
    payload: {
      payment: {
        entity: {
          id: gatewayPaymentId,
          order_id: payment.gateway_order_id || `order_sandbox_${payment.id}`,
          amount: (amount !== undefined ? amount : payment.amount) * 100,
          currency: 'INR',
          method: 'upi',
          receipt: payment.id,
          error_description: failureReason || null,
          acquirer_data: {
            rrn: `992837${Date.now().toString().slice(-6)}`,
            upi_transaction_id: `UPI${Date.now()}`,
          },
        },
      },
    },
  };

  const rawBody = JSON.stringify(webhookBody);
  const secret = process.env.PAYMENT_WEBHOOK_SECRET || 'sandbox_test_webhook_secret';
  const validSignature = crypto.createHmac('sha256', secret).update(rawBody).digest('hex');
  const signatureToUse = invalidSignature ? 'invalid_signature_hash_12345' : validSignature;

  try {
    const result = PaymentService.processGatewayWebhook(webhookBody, signatureToUse, rawBody);
    const updatedPayment = db.findPaymentById(payment.id);
    const updatedCampaign = db.findCampaignById(payment.campaign_id);

    res.json({
      success: true,
      webhookResult: result,
      payment: updatedPayment,
      campaign: updatedCampaign,
    });
  } catch (err: any) {
    const statusCode = err.message === 'Invalid webhook signature' ? 401 : 400;
    res.status(statusCode).json({
      success: false,
      error: err.message,
    });
  }
});

// ==========================================
// 4B. CUSTOMER WALLET & ADD FUNDS API
// ==========================================

// Get customer wallet data (balance and transaction history with live auto-reconciliation)
apiRouter.get('/wallet', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const data = await WalletService.getWalletData(req.user!.id);
    const isOwner = req.user!.email.trim().toLowerCase() === 'sahil272025@gmail.com';
    const promoClaimed = Boolean(
      req.user!.promotional_credit_granted ||
      (isOwner && db.isOwnerPromotionalCreditClaimed(req.user!.id, req.user!.email))
    );
    res.json({
      ...data,
      promotional_credit_granted: promoClaimed,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to fetch wallet data' });
  }
});

// Explicitly sync and reconcile customer wallet with live Razorpay transactions
apiRouter.post('/wallet/sync', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const result = await WalletService.reconcileUserLivePayments(req.user!.id);
    res.json({
      success: true,
      creditedCount: result.creditedCount,
      balance: result.newBalance,
      transactions: result.transactions,
      message: result.creditedCount > 0
        ? `Successfully synced and credited ${result.creditedCount} new live payment(s). Current balance: ₹${result.newBalance.toFixed(2)}`
        : 'Wallet is already synchronized with all payment gateway records.',
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to sync live payments' });
  }
});

// Get customer wallet balance only
apiRouter.get('/wallet/balance', requireAuth, (req: AuthenticatedRequest, res) => {
  try {
    const balance = db.getWalletBalance(req.user!.id);
    res.json({ balance, currency: 'INR' });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to fetch wallet balance' });
  }
});

// Get customer wallet transaction history
apiRouter.get('/wallet/transactions', requireAuth, (req: AuthenticatedRequest, res) => {
  try {
    const transactions = db.getWalletTransactions(req.user!.id);
    const balance = db.getWalletBalance(req.user!.id);
    res.json({ transactions, balance, currency: 'INR' });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to fetch wallet transactions' });
  }
});

// Create Add Funds order for Razorpay checkout
apiRouter.post('/wallet/add-funds', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const { amount } = req.body;
    const result = await WalletService.createAddFundsOrder(req.user!.id, amount);
    res.json(result);
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Failed to initiate Add Funds order' });
  }
});

// Verify Add Funds payment and credit customer wallet
apiRouter.post('/wallet/verify-payment', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const { paymentId, gatewayPaymentId, gatewayOrderId, gatewaySignature } = req.body;
    if (!paymentId || !gatewayPaymentId) {
      return res.status(400).json({ error: 'paymentId and gatewayPaymentId are required' });
    }
    const result = await WalletService.verifyPaymentAndCreditWallet(req.user!.id, {
      paymentId,
      gatewayPaymentId,
      gatewayOrderId,
      gatewaySignature,
    });
    res.json(result);
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Payment verification failed' });
  }
});

// Pay campaign using wallet balance (deducts funds atomically and marks campaign paid)
apiRouter.post('/wallet/pay-campaign', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const { campaignId } = req.body;
    if (!campaignId) {
      return res.status(400).json({ error: 'campaignId is required' });
    }
    const result = await WalletService.payCampaignWithWallet(req.user!.id, campaignId);
    res.json(result);
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Failed to pay with wallet' });
  }
});

// Customer Self-Reset endpoint is PERMANENTLY DISABLED in production
apiRouter.post('/wallet/reset-test-balance', requireAuth, (_req: AuthenticatedRequest, res) => {
  res.status(403).json({
    error: 'Customer self-reset of wallet balance is permanently disabled in production to safeguard verified funds. For balance reconciliation, please contact an authorized administrator.',
    code: 'FEATURE_DISABLED_IN_PRODUCTION',
  });
});

// Admin endpoint: Get full customer wallets overview and transaction ledger
apiRouter.get('/admin/wallets', requireAdmin, (_req, res) => {
  try {
    const data = WalletService.getAdminWalletData();
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to fetch admin wallet overview' });
  }
});

// Admin endpoint: Audit specific customer wallet against verified payment receipts
apiRouter.get('/admin/wallets/:userId/audit', requireAdmin, (req, res) => {
  try {
    const summary = WalletService.getWalletAuditSummary(req.params.userId);
    res.json(summary);
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Failed to fetch customer wallet audit' });
  }
});

// Admin endpoint: Reconcile customer wallet and restore legitimate balance from verified Razorpay payments
apiRouter.post('/admin/wallets/:userId/reconcile-balance', requireAdmin, (req: AuthenticatedRequest, res) => {
  try {
    const adminUserId = req.user?.id || 'admin';
    const auditReason = req.body?.reason || `Admin ledger reconciliation authorized by ${req.user?.email || adminUserId}`;
    const result = WalletService.reconcileAndRestoreLegitimateBalance(
      req.params.userId,
      adminUserId,
      auditReason
    );
    res.json({
      success: true,
      ...result,
      message: result.status === 'RESTORED'
        ? `Customer wallet successfully reconciled: restored ₹${result.correctionAmount.toFixed(2)}. New verified balance: ₹${result.restoredBalance.toFixed(2)}.`
        : `Customer wallet is already in sync with verified payments. Current balance: ₹${result.restoredBalance.toFixed(2)}.`,
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Failed to reconcile customer wallet balance' });
  }
});

// Admin endpoint: Reset customer unverified or test balance to ₹0 (Guarded with safety checks)
apiRouter.post('/admin/wallets/:userId/reset', requireAdmin, (req, res) => {
  try {
    const reason = req.body?.reason || 'Admin reset unverified test balance';
    const result = WalletService.resetTestBalance(req.params.userId, reason);
    res.json({
      success: true,
      message: `Customer balance successfully reset from ₹${result.previousBalance.toFixed(2)} to ₹0.00`,
      balance: 0,
      transaction: result.transaction,
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Failed to reset customer wallet balance' });
  }
});

// Admin/Owner endpoint: Check and claim one-time owner promotional credit (strictly for sahil272025@gmail.com)
apiRouter.post('/admin/owner/claim-promo-credit', requireAdmin, (req: AuthenticatedRequest, res) => {
  try {
    const user = req.user!;
    if (user.email.trim().toLowerCase() !== 'sahil272025@gmail.com') {
      return res.status(403).json({ error: 'Only the verified owner account (sahil272025@gmail.com) is eligible for owner promotional advertising credits.' });
    }

    const result = db.checkAndGrantOwnerPromotionalCredit(user.id);
    res.json({
      success: true,
      granted: result.granted,
      alreadyGranted: result.alreadyGranted,
      amount: result.amount,
      wallet_balance: result.newBalance,
      message: result.granted
        ? 'Owner promotional credit of ₹50,000 successfully allocated to your wallet.'
        : 'Owner promotional credit was already allocated to this account.',
      transaction: result.transaction,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to process owner promotional credit' });
  }
});

// ==========================================
// 5. META / FACEBOOK & INSTAGRAM INTEGRATION
// ==========================================
apiRouter.get('/meta/status', (req, res) => {
  const status = MetaService.getConfigStatus(getRequestOrigin(req));
  res.json(status);
});

// Comprehensive Meta Activation Prerequisites and Blockers Checklist
apiRouter.get('/meta/activation-status', async (_req, res) => {
  try {
    const activation = await MetaService.getActivationStatus();
    res.json(activation);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to retrieve Meta activation status' });
  }
});

// Dynamic minimum daily budget floor from Meta Graph API
apiRouter.get('/meta/minimum-budget', async (req, res) => {
  try {
    const currency = String(req.query.currency || 'INR');
    const rawBilling = String(req.query.billingEvent || 'IMPRESSIONS');
    const billingEvent: 'IMPRESSIONS' | 'LINK_CLICKS' | 'ACTIONS' =
      rawBilling === 'LINK_CLICKS' || rawBilling === 'ACTIONS' ? rawBilling : 'IMPRESSIONS';
    const objective = req.query.objective ? String(req.query.objective) : undefined;
    const adAccountId = req.query.adAccountId ? String(req.query.adAccountId) : '1627260695520511';

    const budgetInfo = await MetaService.getAdAccountMinimumBudget(adAccountId, currency, billingEvent, objective);
    res.json(budgetInfo);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to retrieve Meta minimum budget' });
  }
});

// Safe Read-Only Campaign Pre-Flight Validation (Dry-Run Mode)
apiRouter.post('/meta/validate-campaign', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    let campaign: any = null;
    if (req.body.campaignId) {
      campaign = db.findCampaignById(req.body.campaignId);
      if (!campaign) {
        return res.status(404).json({ error: 'Campaign not found' });
      }
      if (req.user!.role !== 'admin' && campaign.user_id !== req.user!.id) {
        return res.status(403).json({ error: 'Unauthorized' });
      }
    } else {
      campaign = {
        ...req.body,
        user_id: req.user!.id,
      };
    }

    const metaConn = db.findMetaConnectionByUserId(req.user!.id);
    const result = await MetaService.validateCampaignPreFlight(campaign, metaConn);
    res.json(result);
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Pre-flight validation failed' });
  }
});

// Safe read-only verification of Meta API connection, assets and permissions
apiRouter.get('/meta/verify', requireAuth, async (_req, res) => {
  try {
    const report = await MetaService.verifyConnection();
    res.json(report);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Meta verification failed' });
  }
});

apiRouter.get('/meta/oauth/url', requireAuth, (req: AuthenticatedRequest, res) => {
  const state = JSON.stringify({ userId: req.user!.id, timestamp: Date.now() });
  const result = MetaService.getOAuthUrl(state, getRequestOrigin(req));
  if (result.error) {
    return res.status(400).json({ error: result.error });
  }
  res.json({ url: result.url });
});

apiRouter.get('/meta/oauth/callback', async (req, res) => {
  const { code, state, error, error_description } = req.query;

  if (error) {
    return res.redirect(`/dashboard/profile?meta_error=${encodeURIComponent(String(error_description || error))}`);
  }

  if (!code) {
    return res.redirect('/dashboard/profile?meta_error=Authorization%20code%20missing');
  }

  try {
    let userId: string | null = null;
    if (state) {
      try {
        const parsed = JSON.parse(String(state));
        userId = parsed.userId;
      } catch {
        // state parse fallback
      }
    }

    const exchange = await MetaService.exchangeOAuthCode(String(code), getRequestOrigin(req));
    if (!exchange.success || !exchange.connection) {
      return res.redirect(`/dashboard/profile?meta_error=${encodeURIComponent(exchange.error || 'Meta authorization failed')}`);
    }

    if (userId) {
      exchange.connection.user_id = userId;
      db.saveMetaConnection(exchange.connection);
    }

    res.redirect('/dashboard/profile?meta_success=true');
  } catch (err: any) {
    res.redirect(`/dashboard/profile?meta_error=${encodeURIComponent(err?.message || 'Meta OAuth failed')}`);
  }
});

apiRouter.post('/meta/select-account', requireAuth, (req: AuthenticatedRequest, res) => {
  const { adAccountId, pageId, instagramId } = req.body;
  const connection = db.findMetaConnectionByUserId(req.user!.id);
  if (!connection) {
    return res.status(400).json({ error: 'Meta account not connected' });
  }

  if (adAccountId) {
    connection.selected_ad_account_id = adAccountId;
  }
  if (pageId) {
    connection.selected_page_id = pageId;
    connection.page_id = pageId;
    const pageObj = connection.pages?.find(p => p.id === pageId);
    if (pageObj) {
      connection.page_name = pageObj.name;
    }
  }
  if (instagramId) {
    connection.selected_instagram_id = instagramId;
    connection.instagram_id = instagramId;
    const igObj = connection.instagram_accounts?.find(ig => ig.id === instagramId);
    if (igObj) {
      connection.instagram_username = igObj.username;
    }
  }

  db.saveMetaConnection(connection);
  res.json({ success: true, connection });
});

apiRouter.post('/meta/select-page', requireAuth, (req: AuthenticatedRequest, res) => {
  const { pageId } = req.body;
  const connection = db.findMetaConnectionByUserId(req.user!.id);
  if (!connection) {
    return res.status(400).json({ error: 'Meta account not connected' });
  }

  connection.selected_page_id = pageId;
  connection.page_id = pageId;
  const pageObj = connection.pages?.find(p => p.id === pageId);
  if (pageObj) {
    connection.page_name = pageObj.name;
    if (pageObj.instagram_account_id && !connection.selected_instagram_id) {
      connection.selected_instagram_id = pageObj.instagram_account_id;
      connection.instagram_id = pageObj.instagram_account_id;
      connection.instagram_username = pageObj.instagram_username;
    }
  }
  db.saveMetaConnection(connection);
  res.json({ success: true, connection });
});

apiRouter.post('/meta/select-instagram', requireAuth, (req: AuthenticatedRequest, res) => {
  const { instagramId } = req.body;
  const connection = db.findMetaConnectionByUserId(req.user!.id);
  if (!connection) {
    return res.status(400).json({ error: 'Meta account not connected' });
  }

  connection.selected_instagram_id = instagramId;
  connection.instagram_id = instagramId;
  const igObj = connection.instagram_accounts?.find(ig => ig.id === instagramId);
  if (igObj) {
    connection.instagram_username = igObj.username;
  }
  db.saveMetaConnection(connection);
  res.json({ success: true, connection });
});

apiRouter.delete('/meta/disconnect', requireAuth, (req: AuthenticatedRequest, res) => {
  db.deleteMetaConnection(req.user!.id);
  res.json({ success: true, message: 'Meta advertising account disconnected' });
});

apiRouter.post('/meta/estimate-audience', requireAuth, async (req: AuthenticatedRequest, res) => {
  const connection = db.findMetaConnectionByUserId(req.user!.id);
  const result = await MetaService.getAudienceEstimate(
    connection?.selected_ad_account_id || '',
    req.body.targeting,
    connection?.access_token || ''
  );
  res.json(result);
});

// ==========================================
// 6. SUPPORT TICKETS
// ==========================================
apiRouter.get('/support', requireAuth, (req: AuthenticatedRequest, res) => {
  const tickets = db.getTickets(req.user!.id);
  res.json({ tickets });
});

apiRouter.post('/support', requireAuth, (req: AuthenticatedRequest, res) => {
  try {
    const ticket = SupportService.createTicket({
      userId: req.user!.id,
      subject: req.body.subject,
      message: req.body.message,
      campaignId: req.body.campaignId,
      attachmentUrl: req.body.attachmentUrl,
    });
    res.status(201).json({ ticket });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Failed to create support ticket' });
  }
});

apiRouter.get('/support/:id', requireAuth, (req: AuthenticatedRequest, res) => {
  const ticket = db.findTicketById(req.params.id);
  if (!ticket) return res.status(404).json({ error: 'Ticket not found' });
  if (req.user!.role !== 'admin' && ticket.user_id !== req.user!.id) {
    return res.status(403).json({ error: 'Unauthorized' });
  }
  res.json({ ticket });
});

apiRouter.post('/support/:id/reply', requireAuth, (req: AuthenticatedRequest, res) => {
  try {
    const updated = SupportService.addReply(
      req.params.id,
      req.user!.id,
      req.user!.role === 'admin' ? 'admin' : 'user',
      req.body.message
    );
    res.json({ ticket: updated });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Failed to add reply' });
  }
});

// ==========================================
// 7. ADMIN DASHBOARD
// ==========================================
apiRouter.get('/admin/stats', requireAdmin, (_req, res) => {
  const users = db.getUsers().filter(u => u.role !== 'admin');
  const campaigns = db.getCampaigns();
  const payments = db.getPayments();

  const activeCampaigns = campaigns.filter(c => c.status === 'ACTIVE').length;
  const pendingCampaigns = campaigns.filter(c => c.status === 'PAYMENT_PENDING' || c.status === 'UNDER_REVIEW' || c.status === 'SUBMITTING').length;
  const completedCampaigns = campaigns.filter(c => c.status === 'COMPLETED').length;

  const verifiedPayments = payments.filter(p => p.status === 'PAID');
  const totalRevenue = verifiedPayments.reduce((sum, p) => sum + p.amount, 0);

  res.json({
    totalCustomers: users.length,
    totalCampaigns: campaigns.length,
    activeCampaigns,
    pendingCampaigns,
    completedCampaigns,
    totalVerifiedPayments: verifiedPayments.length,
    totalRevenue,
  });
});

apiRouter.get('/admin/customers', requireAdmin, (_req, res) => {
  const users = db.getUsers().map(u => ({
    id: u.id,
    name: u.name,
    email: u.email,
    phone: u.phone,
    role: u.role,
    wallet_balance: typeof u.wallet_balance === 'number' && !isNaN(u.wallet_balance) ? u.wallet_balance : db.getWalletBalance(u.id),
    promotional_credit_granted: Boolean(u.promotional_credit_granted || (u.email.toLowerCase() === 'sahil272025@gmail.com' && db.isOwnerPromotionalCreditClaimed(u.id, u.email))),
    created_at: u.created_at,
  }));
  res.json({ customers: users });
});

apiRouter.get('/admin/campaigns', requireAdmin, (_req, res) => {
  const campaigns = db.getCampaigns();
  res.json({ campaigns });
});

apiRouter.get('/admin/payments', requireAdmin, (_req, res) => {
  const payments = db.getPayments();
  res.json({ payments });
});

apiRouter.post('/admin/payments/:id/verify', requireAdmin, (req, res) => {
  try {
    const updated = PaymentService.markPaymentAsPaid(req.params.id, {
      source: 'ADMIN_MANUAL_VERIFICATION',
      transaction_reference: req.body.transactionReference,
      notes: req.body.notes || 'Verified by administrator.',
    });
    res.json({ payment: updated, message: 'Payment verified successfully.' });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Payment verification failed' });
  }
});

apiRouter.post('/admin/payments/:id/reject', requireAdmin, (req, res) => {
  try {
    const updated = PaymentService.adminRejectPayment(req.params.id, req.body.reason || 'Verification rejected');
    res.json({ payment: updated, message: 'Payment rejected.' });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Failed to reject payment' });
  }
});

apiRouter.get('/admin/packages', requireAdmin, (_req, res) => {
  res.json({ packages: db.getPackages(false) });
});

apiRouter.put('/admin/packages/:id', requireAdmin, (req, res) => {
  const updated = db.updatePackage(req.params.id, req.body);
  if (!updated) return res.status(404).json({ error: 'Package not found' });
  res.json({ package: updated });
});

apiRouter.post('/admin/packages', requireAdmin, (req, res) => {
  const newPkg = db.createPackage({
    id: `pkg_${Date.now()}`,
    name: req.body.name,
    price: Number(req.body.price),
    duration_days: Number(req.body.duration_days),
    platforms: ['Facebook', 'Instagram'],
    features: req.body.features || [],
    active: req.body.active ?? true,
    created_at: new Date().toISOString(),
  });
  res.status(201).json({ package: newPkg });
});

apiRouter.get('/admin/logs', requireAdmin, (req, res) => {
  const limit = req.query.limit ? Number(req.query.limit) : 100;
  res.json({ logs: db.getLogs(limit) });
});

apiRouter.get('/admin/tickets', requireAdmin, (_req, res) => {
  res.json({ tickets: db.getTickets() });
});

apiRouter.put('/admin/tickets/:id/status', requireAdmin, (req, res) => {
  const updated = SupportService.updateStatus(req.params.id, req.body.status);
  res.json({ ticket: updated });
});

// Secure Read-Only Admin Diagnostic Endpoint
apiRouter.get('/admin/diagnostics', requireAdmin, async (_req, res) => {
  try {
    const queueStats = CampaignQueueService.getQueueStats();
    const token = MetaService.getServerAccessToken();
    const activation = await MetaService.getActivationStatus();
    const recentLogs = db.getLogs(50).filter(l => l.category === 'META_API' || l.category === 'QUEUE');

    res.json({
      timestamp: new Date().toISOString(),
      service: 'SMAP Advertising Platform',
      version: '1.2.0-ads-only',
      environment: process.env.NODE_ENV || 'production',
      metaEnvironmentPresence: {
        META_APP_ID: Boolean(process.env.META_APP_ID && process.env.META_APP_ID.trim().length > 0),
        META_APP_SECRET: Boolean(process.env.META_APP_SECRET && process.env.META_APP_SECRET.trim().length > 0),
        META_ACCESS_TOKEN: Boolean(process.env.META_ACCESS_TOKEN && process.env.META_ACCESS_TOKEN.trim().length > 0),
        META_SYSTEM_USER_TOKEN: Boolean(process.env.META_SYSTEM_USER_TOKEN && process.env.META_SYSTEM_USER_TOKEN.trim().length > 0),
        META_LIVE_SUBMISSIONS_ENABLED: process.env.META_LIVE_SUBMISSIONS_ENABLED === 'true',
        META_API_VERSION: process.env.META_API_VERSION || 'v21.0',
        META_REDIRECT_URI: Boolean(process.env.META_REDIRECT_URI),
        APP_URL: Boolean(process.env.APP_URL),
        activeTokenConfigured: Boolean(token),
      },
      metaApp: activation.metaApp,
      assets: activation.assets,
      permissions: activation.permissions,
      safetyGate: {
        liveSubmissionsEnabled: activation.liveSubmissionsEnabled,
        allPrerequisitesMet: activation.allPrerequisitesMet,
        blockers: activation.blockers,
        actionableSteps: activation.actionableSteps,
      },
      workerHealth: {
        running: true,
        stats: queueStats,
      },
      recentSafeLogs: recentLogs.slice(0, 10).map(l => ({
        created_at: l.created_at,
        category: l.category,
        level: l.level,
        message: l.message,
      })),
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Diagnostic query failed' });
  }
});

