import express from 'express';
import path from 'path';
import fs from 'fs';
import cookieParser from 'cookie-parser';
import dotenv from 'dotenv';
import { apiRouter, handleGoogleOAuthCallback } from './src/server/routes.js';
import { SchedulerService } from './src/server/schedulerService.js';
import { CampaignQueueService } from './src/server/campaignQueue.js';
import { renderPolicyHtml, registerPolicyRoutes } from './src/server/policyPages.js';
import { RENDER_PRODUCTION_REDIRECT_URI, DEFAULT_GOOGLE_CLIENT_ID } from './src/server/authService.js';
import { VERIFIED_META_ACCESS_TOKEN } from './src/server/metaTokenFallback.js';

dotenv.config({ override: true });

// Load .dev.env.json if present in parent or root (injected by AI Studio environment)
const devEnvLocations = ['/app/.dev.env.json', './.dev.env.json', '../.dev.env.json'];
for (const loc of devEnvLocations) {
  if (fs.existsSync(loc)) {
    try {
      const raw = fs.readFileSync(loc, 'utf8');
      const parsed = JSON.parse(raw);
      for (const [key, val] of Object.entries(parsed)) {
        if (typeof val === 'string' && val.trim().length > 0 && !process.env[key]) {
          process.env[key] = val;
        }
      }
      break;
    } catch {
      // ignore
    }
  }
}

// Default to existing SMAP Google Client ID if not provided
if (!process.env.GOOGLE_CLIENT_ID || process.env.GOOGLE_CLIENT_ID.trim().length === 0) {
  process.env.GOOGLE_CLIENT_ID = DEFAULT_GOOGLE_CLIENT_ID;
}

// Ensure verified META_ACCESS_TOKEN is configured in process.env for all services
if (!process.env.META_ACCESS_TOKEN) {
  if (process.env.META_SYSTEM_USER_TOKEN && process.env.META_SYSTEM_USER_TOKEN.trim().length > 0) {
    process.env.META_ACCESS_TOKEN = process.env.META_SYSTEM_USER_TOKEN.trim();
  } else if (VERIFIED_META_ACCESS_TOKEN) {
    process.env.META_ACCESS_TOKEN = VERIFIED_META_ACCESS_TOKEN;
  }
}

// Verify and ensure Google OAuth redirect URI is configured
if (!process.env.GOOGLE_REDIRECT_URI) {
  process.env.GOOGLE_REDIRECT_URI = RENDER_PRODUCTION_REDIRECT_URI;
}

const app = express();
app.set('trust proxy', true);
// AI Studio dev server runs behind an nginx reverse proxy on 8080 that forwards to 3000.
// On external hosting platforms (Render, Railway, Heroku, Fly.io, VPS), the platform provides PORT (e.g. 10000).
const isAIStudio = Boolean(process.env.APPLET_ID || process.env.NGINX_PORT);
const PORT = isAIStudio ? 3000 : (Number(process.env.PORT) || 3000);
const isProduction = process.env.NODE_ENV === 'production';

// Body parsing & cookies
app.use(express.json({
  limit: '50mb',
  verify: (req: any, _res, buf) => {
    req.rawBody = buf;
  },
}));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));
app.use(cookieParser());

// Static uploads directory
const DEFAULT_DATA_DIR = path.resolve(process.cwd(), 'data');
const DATA_DIR = process.env.RENDER_DISK_PATH ||
  process.env.DATA_DIR ||
  (fs.existsSync('/var/data') ? '/var/data' : DEFAULT_DATA_DIR);
const uploadsDir = path.join(DATA_DIR, 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}
app.use('/api/uploads', express.static(uploadsDir));

// Explicitly register real Google OAuth 2.0 callback endpoint at root level & api level
app.all(['/api/auth/google/callback', '/api/auth/google/callback/', '/auth/google/callback', '/auth/google/callback/'], handleGoogleOAuthCallback);

// API routes
app.use('/api', apiRouter);

// Publicly accessible legal & compliance pages (About, Privacy, Terms, Refund, Data Deletion, Pricing, Contact)
// Directly returns semantic, readable HTML with HTTP 200 for Meta App Review, Razorpay verification & external crawlers
registerPolicyRoutes(app);

// Explicit robots.txt allowing all web crawlers & verifiers (Razorpay, Googlebot, etc.)
app.get('/robots.txt', (_req, res) => {
  res.type('text/plain').send('User-agent: *\nAllow: /\n');
});

// Lightweight public health check endpoint
app.get('/health', (_req, res) => {
  res.status(200).json({
    status: 'ok',
    service: 'SMAP Advertising Platform',
    version: '1.2.0-ads-only',
    buildDate: '2026-10-26T10:35:00Z',
    workerActive: true,
    liveSubmissionsEnabled: process.env.META_LIVE_SUBMISSIONS_ENABLED === 'true',
    timestamp: new Date().toISOString(),
  });
});

// Explicit download endpoint for patch and export archives
app.get('/exports/:filename', (req, res) => {
  const filename = path.basename(req.params.filename);
  const filePath = path.resolve(process.cwd(), 'exports', filename);

  if (!fs.existsSync(filePath)) {
    return res.status(404).send('File not found');
  }

  const stat = fs.statSync(filePath);

  res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
  res.setHeader('Content-Length', stat.size);
  res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);

  if (filename.endsWith('.tar.gz') || filename.endsWith('.tgz')) {
    res.setHeader('Content-Type', 'application/gzip');
  } else if (filename.endsWith('.zip')) {
    res.setHeader('Content-Type', 'application/zip');
  } else if (filename.endsWith('.patch')) {
    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
  } else {
    res.setHeader('Content-Type', 'application/octet-stream');
  }

  const stream = fs.createReadStream(filePath);
  stream.pipe(res);
});

// Start campaign expiry background scheduler
SchedulerService.start(30000); // Check every 30 seconds

// Start resilient background campaign submission queue (with crash recovery)
CampaignQueueService.start();

// Frontend integration
if (!isProduction) {
  const { createServer: createViteServer } = await import('vite');
  const vite = await createViteServer({
    server: {
      middlewareMode: true,
      port: PORT,
      host: '0.0.0.0',
      hmr: false,
      allowedHosts: true,
    },
    appType: 'spa',
  });
  app.use(vite.middlewares);
} else {
  const distDir = path.resolve(process.cwd(), 'dist');
  app.use(express.static(distDir, {
    setHeaders: (res, filePath) => {
      if (filePath.endsWith('.html')) {
        res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
      } else if (filePath.includes('/assets/')) {
        res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
      }
    },
  }));
  app.get('*', (_req, res) => {
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    res.sendFile(path.join(distDir, 'index.html'));
  });
}

const server = app.listen(PORT, '0.0.0.0', () => {
  console.log(`SMAP advertising server running at http://0.0.0.0:${PORT} [${isProduction ? 'PRODUCTION' : 'DEVELOPMENT'}]`);
});
server.timeout = 600000; // 10 minutes timeout for high-res video uploads
server.keepAliveTimeout = 65000;
server.headersTimeout = 66000;
