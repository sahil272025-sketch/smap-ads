export interface User {
  id: string;
  google_sub: string;
  name: string;
  email: string;
  email_verified: boolean;
  profile_picture: string | null;
  phone?: string;
  wallet_balance?: number;
  promotional_credit_granted?: boolean;
  language?: 'en' | 'hi';
  role: 'customer' | 'admin';
  status: 'ACTIVE' | 'SUSPENDED';
  created_at: string;
  last_login_at: string;
}

export interface GoogleConfigStatus {
  isConfigured: boolean;
  clientId: string | null;
  clientIdMasked: string | null;
  redirectUri: string;
  hasClientSecret: boolean;
  hasRedirectWarning?: boolean;
  isDevEnvironment?: boolean;
  statusMessage: string;
}

export interface Package {
  id: string;
  name: string;
  price: number;
  duration_days: number;
  platform_fee?: number;
  media_spend?: number;
  platforms: string[];
  features: string[];
  active: boolean;
  is_popular?: boolean;
}

export type CampaignObjective = 'AWARENESS' | 'TRAFFIC' | 'ENGAGEMENT' | 'LEADS' | 'SALES';

export type PlacementType = 'facebook_feed' | 'instagram_feed' | 'instagram_stories' | 'instagram_reels';

export type CampaignStatus = 
  | 'DRAFT'
  | 'QUEUED'
  | 'PENDING_REVIEW'
  | 'PAYMENT_PENDING'
  | 'PAYMENT_CONFIRMED'
  | 'META_NOT_CONNECTED'
  | 'SUBMITTING'
  | 'UNDER_REVIEW'
  | 'ACTIVE'
  | 'PAUSED'
  | 'COMPLETED'
  | 'REJECTED'
  | 'FAILED'
  | 'BUDGET_ADJUSTMENT_REQUIRED';

export interface CampaignTargeting {
  country: string;
  state: string;
  city: string;
  min_age: number;
  max_age: number;
  gender: 'ALL' | 'MEN' | 'WOMEN';
  interests: string[];
  locations?: string[];
  estimated_audience_size?: string;
}

export interface Campaign {
  id: string;
  user_id: string;
  package_id: string;
  objective?: CampaignObjective;
  creative_url: string;
  creative_type: 'image' | 'video';
  business_name: string;
  primary_text: string;
  headline: string;
  description: string;
  call_to_action?: string;
  destination_type: 'website' | 'whatsapp' | 'facebook_page' | 'instagram_profile' | 'instagram' | 'phone';
  destination_url: string;
  phone_number?: string;
  placements?: PlacementType[];
  targeting: CampaignTargeting;
  daily_budget?: number;
  duration_days?: number;
  total_budget?: number;
  budget_breakdown?: {
    platform_fee: number;
    media_spend: number;
    daily_media_spend: number;
    min_daily_media_spend: number;
    currency: string;
    recommended_duration_days?: number;
    recommended_topup_amount?: number;
  };
  start_at: string | null;
  end_at: string | null;
  status: CampaignStatus;
  queue_status?: 'QUEUED' | 'PROCESSING' | 'COMPLETED' | 'RETRYING' | 'FAILED' | null;
  retry_count?: number;
  last_retry_at?: string | null;
  next_retry_at?: string | null;
  last_synced_at?: string | null;
  meta_campaign_id: string | null;
  meta_adset_id: string | null;
  meta_creative_id: string | null;
  meta_ad_id: string | null;
  meta_account_id: string | null;
  meta_status_message: string | null;
  rejection_reason: string | null;
  error_details: string | null;
  created_at: string;
  updated_at: string;
}

export type PaymentStatus = 
  | 'PENDING'
  | 'VERIFICATION_PENDING'
  | 'PAID'
  | 'FAILED'
  | 'CANCELLED'
  | 'REFUND_PENDING'
  | 'REFUNDED';

export interface Payment {
  id: string;
  user_id: string;
  campaign_id: string;
  package_id: string;
  amount: number;
  currency: 'INR';
  payment_method: 'UPI';
  payee_upi: string;
  upi_intent_url: string;
  transaction_reference: string | null; // UTR or customer reference
  gateway_payment_id: string | null;
  gateway_order_id: string | null;
  gateway_key_id?: string | null;
  status: PaymentStatus;
  webhook_status?: 'PENDING' | 'PROCESSED' | 'FAILED' | null;
  failure_reason?: string | null;
  idempotency_key?: string | null;
  paid_at?: string | null;
  verified_at: string | null;
  verification_source: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

export interface MetaConnectionState {
  connected: boolean;
  meta_user_name?: string;
  ad_accounts?: Array<{
    id: string;
    account_id: string;
    name: string;
    currency: string;
    account_status: number;
  }>;
  selected_ad_account_id?: string | null;
  pages?: Array<{
    id: string;
    name: string;
    category?: string;
    tasks?: string[];
    instagram_account_id?: string;
    instagram_username?: string;
  }>;
  selected_page_id?: string | null;
  instagram_accounts?: Array<{
    id: string;
    username: string;
    name?: string;
    page_id?: string;
  }>;
  selected_instagram_id?: string | null;
  expires_at?: string;
  page_id?: string;
  page_name?: string;
  instagram_id?: string;
  instagram_username?: string;
  ad_account_id?: string;
  ad_account_name?: string;
  is_server_verified?: boolean;
}

export interface MetaAssetAccess {
  adAccount: {
    verified: boolean;
    id: string | null;
    accountId: string | null;
    name: string | null;
    currency: string | null;
    accountStatus: number | null;
    statusText: string;
    hasPaymentMethods: boolean;
    canCreateCallAds: boolean;
    capabilitiesCount: number;
    error?: string;
  };
  facebookPage: {
    verified: boolean;
    id: string | null;
    name: string | null;
    category: string | null;
    tasks: string[];
    canAdvertise: boolean;
    error?: string;
  };
  instagramAccount: {
    verified: boolean;
    id: string | null;
    username: string | null;
    statusText: string;
    notice: string;
    error?: string;
  };
  metaApp: {
    verified: boolean;
    id: string | null;
    name: string | null;
    error?: string;
  };
}

export interface MetaPermissionsCheck {
  ads_management: boolean;
  ads_read: boolean;
  business_management: boolean;
  pages_manage_ads: boolean;
  pages_read_engagement: boolean;
  pages_show_list: boolean;
  grantedScopes: string[];
  missingScopes: string[];
  pageTasks: string[];
}

export interface MetaVerificationReport {
  timestamp: string;
  tokenConfigured: boolean;
  tokenType: string | null;
  isValid: boolean;
  userId: string | null;
  appId: string | null;
  appName: string | null;
  expiresAt: string | null;
  assets: MetaAssetAccess;
  permissions: MetaPermissionsCheck;
  readyForCampaignCreation: boolean;
  summary: string;
  recommendations: string[];
}

export interface CampaignPreFlightResult {
  valid: boolean;
  dryRun: boolean;
  errors: string[];
  warnings: string[];
  details: {
    headlineValid: boolean;
    descriptionValid: boolean;
    destinationValid: boolean;
    creativeValid: boolean;
    budgetValid: boolean;
    pageConnected: boolean;
    instagramConnected: boolean;
    dailyMediaSpend: number;
    minDailyBudget: number;
    currency: string;
  };
}

export interface MetaActivationStatus {
  liveSubmissionsEnabled: boolean;
  metaApp: {
    appId: string;
    mode: 'DEVELOPMENT' | 'LIVE';
    accessLevel: 'STANDARD_ACCESS' | 'ADVANCED_ACCESS';
    appReviewStatus: 'PENDING_SUBMISSION' | 'IN_REVIEW' | 'APPROVED';
    blockerNotice: string;
  };
  token: {
    configured: boolean;
    tokenType: string;
    valid: boolean;
    expiresAt: string | null;
  };
  permissions: {
    ads_management: boolean;
    ads_read: boolean;
    pages_manage_ads: boolean;
    pages_read_engagement: boolean;
    pages_show_list: boolean;
    grantedScopes: string[];
    missingForLive: string[];
  };
  assets: {
    adAccountId: string;
    adAccountName: string;
    adAccountStatus: number;
    hasPaymentMethods: boolean;
    currency: string;
    facebookPageId: string;
    facebookPageName: string;
    hasPageAdvertiseTask: boolean;
    instagramId: string;
    instagramUsername: string;
  };
  dryRunSupported: boolean;
  allPrerequisitesMet: boolean;
  blockers: string[];
  actionableSteps: string[];
  productionActivationGuide: {
    configKey: 'META_LIVE_SUBMISSIONS_ENABLED';
    requiredValue: 'true';
    location: string;
    prerequisitesSummary: string;
  };
}

export interface MetaInsights {
  reach: number | null;
  impressions: number | null;
  clicks: number | null;
  spend: number | null;
  ctr: number | null;
  cpc: number | null;
  dataAvailable: boolean;
  notice: string;
  lastSyncedAt?: string | null;
  syncStatus?: 'LIVE_SYNCHRONIZED' | 'PENDING_DELIVERY' | 'NO_META_ID' | 'SYNC_ERROR' | string | null;
}

export interface PerformanceCampaignItem {
  id: string;
  businessName: string;
  headline: string;
  creativeUrl: string;
  creativeType: 'image' | 'video';
  packageName: string;
  packagePrice: number;
  platforms: string[];
  status: CampaignStatus;
  queueStatus?: string | null;
  metaCampaignId: string | null;
  metaStatusMessage: string | null;
  rejectionReason: string | null;
  errorDetails: string | null;
  startAt: string | null;
  endAt: string | null;
  createdAt: string;
  insights: MetaInsights;
  syncStatus: string;
  lastSyncedAt: string | null;
}

export interface PerformanceReportsData {
  summary: {
    totalImpressions: number;
    totalReach: number;
    totalClicks: number;
    totalSpend: number;
    averageCtr: number | null;
    averageCpc: number | null;
    totalCampaigns: number;
    activeCampaignsCount: number;
    inReviewCount: number;
    queuedCount: number;
    completedCount: number;
    failedCount: number;
    hasLiveMetrics: boolean;
  };
  campaigns: PerformanceCampaignItem[];
  lastSyncedAt: string;
  disclosures: {
    impressionsVsReach: string;
    reportingLatency: string;
    reviewWindow: string;
  };
}

export interface QueueStatusData {
  success: boolean;
  stats: {
    queuedCount: number;
    processingCount: number;
    activeWorkers: number;
    completedCount: number;
    failedCount: number;
    retriedCount: number;
    liveSubmissionsEnabled: boolean;
  };
  timestamp: string;
}

export interface SupportTicketReply {
  id: string;
  sender: 'user' | 'admin';
  sender_name: string;
  message: string;
  created_at: string;
}

export interface SupportTicket {
  id: string;
  user_id: string;
  user_name: string;
  user_email: string;
  campaign_id: string | null;
  subject: string;
  message: string;
  attachment_url: string | null;
  status: 'OPEN' | 'IN_PROGRESS' | 'RESOLVED' | 'CLOSED';
  created_at: string;
  updated_at: string;
  replies: SupportTicketReply[];
}

export interface SystemLog {
  id: string;
  category: string;
  level: 'INFO' | 'WARN' | 'ERROR';
  message: string;
  details?: any;
  created_at: string;
}

export interface AdminStats {
  totalCustomers: number;
  totalCampaigns: number;
  activeCampaigns: number;
  pendingCampaigns: number;
  completedCampaigns: number;
  totalVerifiedPayments: number;
  totalRevenue: number;
}

export type WalletTransactionType =
  | 'ADD_FUNDS'
  | 'CAMPAIGN_PAYMENT'
  | 'REFUND'
  | 'FAILED_PAYMENT'
  | 'AUDIT_CORRECTION'
  | 'PROMOTIONAL_CREDIT';

export type WalletTransactionStatus = 'SUCCESS' | 'FAILED' | 'PENDING';

export interface WalletTransaction {
  id: string;
  user_id: string;
  type: WalletTransactionType;
  amount: number;
  balance_before: number;
  balance_after: number;
  description: string;
  payment_id?: string | null;
  gateway_payment_id?: string | null;
  gateway_order_id?: string | null;
  campaign_id?: string | null;
  status: WalletTransactionStatus;
  created_at: string;
}

export interface WalletData {
  balance: number;
  currency: 'INR';
  transactions: WalletTransaction[];
  promotional_credit_granted?: boolean;
}

export interface AdminWalletCustomer {
  userId: string;
  name: string;
  email: string;
  phone?: string;
  currentBalance: number;
  totalFundsAdded: number;
  totalFundsUsed: number;
  transactionsCount: number;
  lastActivityAt?: string;
}

export interface AdminWalletData {
  summary: {
    totalPlatformBalance: number;
    totalFundsAdded: number;
    totalFundsUsed: number;
    totalTransactions: number;
  };
  customers: AdminWalletCustomer[];
  transactions: WalletTransaction[];
}
